"""Collection based outfit and item switches for the SFM Import add-on."""

import bpy
import hashlib
import re
from bpy.props import PointerProperty, StringProperty, BoolProperty, EnumProperty
from mathutils import Vector


class SFMObjectSwitchSettings(bpy.types.PropertyGroup):
    collection: PointerProperty(name="Group", type=bpy.types.Collection)
    skeleton: EnumProperty(name="Skeleton", items=[
        ('SFM', "SFM", "Use the imported Source skeleton"),
        ('RIGIFY', "Rigify", "Use the converted Rigify control rig"),
        ('CUSTOM', "Custom", "Choose an armature manually"),
    ], default='SFM')
    armature: PointerProperty(
        name="Armature", type=bpy.types.Object,
        poll=lambda self, obj: obj is not None and obj.type == 'ARMATURE')
    mode: EnumProperty(name="Action", items=[
        ('SWITCH', "Replace variants", "Show one child collection state at a time"),
        ('ATTACH', "Attach to bone", "Attach selected clothes or accessories to a bone"),
    ], default='SWITCH')
    bone: StringProperty(name="Control bone", default="CTRL_ObjectSwitch")
    property_name: StringProperty(name="Property", default="switch")
    create_bone: BoolProperty(
        name="Create control bone if missing", default=True,
        description="Add a non-deforming control bone to the selected armature")


def selected_armature(context, settings):
    if settings.skeleton == 'CUSTOM':
        return settings.armature
    rig_settings = getattr(context.scene, "sfm_rigify", None)
    if rig_settings is not None:
        candidate = rig_settings.source if settings.skeleton == 'SFM' else rig_settings.rig
        if candidate and candidate.type == 'ARMATURE':
            return candidate
    return settings.armature


def _ensure_bone(context, arm, name):
    if arm.pose.bones.get(name):
        return arm.pose.bones[name]
    old_active = context.view_layer.objects.active
    old_selected = list(context.selected_objects)
    if context.object and context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for obj in context.selected_objects:
        obj.select_set(False)
    arm.select_set(True)
    context.view_layer.objects.active = arm
    bpy.ops.object.mode_set(mode='EDIT')
    try:
        bones = arm.data.edit_bones
        root = next((bone for bone in bones if bone.parent is None), None)
        head = root.head.copy() if root else arm.location.copy()
        offset = root.matrix.to_3x3() @ Vector((0.0, 0.0, 0.1)) if root else Vector((0, 0, 0.1))
        tail = head + offset
        control = bones.new(name)
        control.head = head
        control.tail = tail
        control.use_deform = False
        if root:
            control.parent = root
    finally:
        bpy.ops.object.mode_set(mode='OBJECT')
        for obj in list(context.selected_objects):
            obj.select_set(False)
        for obj in old_selected:
            if obj and obj.name in bpy.data.objects:
                obj.select_set(True)
        if old_active and old_active.name in bpy.data.objects:
            context.view_layer.objects.active = old_active
    return arm.pose.bones.get(name)


def create_switch(context, collection, arm, bone_name, prop, create_bone=True):
    bone_name = bone_name.strip()
    prop = prop.strip()
    if not collection or not arm or not bone_name or not prop:
        raise ValueError("Choose a group, armature, control bone, and property name")
    if not arm.pose.bones.get(bone_name) and create_bone:
        _ensure_bone(context, arm, bone_name)
    bone = arm.pose.bones.get(bone_name)
    if bone is None:
        raise ValueError(f'Control bone "{bone_name}" was not found')

    children = [child for child in collection.children if child.objects or child.children]
    if children:
        states = [(index, list(child.all_objects)) for index, child in enumerate(children)]
    else:
        states = [(index, [obj]) for index, obj in enumerate(collection.objects)]
    states = [(state, objects) for state, objects in states if objects]
    if not states:
        raise ValueError("The selected group is empty")

    bone[prop] = 0
    bone.id_properties_ui(prop).update(min=0, max=len(states) - 1, soft_min=0,
                                       soft_max=len(states) - 1)
    for state, objects in states:
        for obj in objects:
            for path in ("hide_viewport", "hide_render"):
                try:
                    obj.driver_remove(path)
                except Exception:
                    pass
                driver = obj.driver_add(path).driver
                var = driver.variables.new()
                var.name = "state"
                var.targets[0].id = arm
                var.targets[0].data_path = f'pose.bones["{bone_name}"]["{prop}"]'
                driver.expression = f"state != {state}"
    return len(states)


def attach_collection(context, collection, arm, bone_name):
    if not collection or not arm or not bone_name.strip():
        raise ValueError("Choose a collection, skeleton, and attachment bone")
    bone = arm.data.bones.get(bone_name.strip())
    if bone is None:
        raise ValueError(f'Bone "{bone_name}" was not found on {arm.name}')
    objects = list(collection.all_objects)
    if not objects:
        raise ValueError("The selected collection is empty")
    attached = 0
    for obj in objects:
        if obj == arm:
            continue
        world = obj.matrix_world.copy()
        weighted_mesh = obj.type == 'MESH' and len(obj.vertex_groups) > 0
        obj.parent = arm
        if weighted_mesh:
            obj.parent_type = 'OBJECT'
            obj.parent_bone = ""
            modifier = next((mod for mod in obj.modifiers if mod.type == 'ARMATURE'), None)
            if modifier is None:
                modifier = obj.modifiers.new(name="SFM Outfit Deform", type='ARMATURE')
            modifier.object = arm
        else:
            obj.parent_type = 'BONE'
            obj.parent_bone = bone.name
        obj.matrix_world = world
        attached += 1
    return attached


def _groups_control_bone(context, arm, name="CTRL_Groups"):
    existing = arm.data.bones.get(name)
    if existing:
        return name
    head_bone = next((bone for bone in arm.data.bones
                      if any(token in bone.name.lower() for token in ("head", "biphead"))), None)
    origin = head_bone.head_local.copy() if head_bone else Vector((0, 0, 0))
    try:
        offset = arm.matrix_world.inverted_safe().to_3x3() @ Vector((0, 0, 0.5))
    except Exception:
        offset = Vector((0, 0, 0.5))
    head = origin + offset

    old_active = context.view_layer.objects.active
    old_selected = list(context.selected_objects)
    if context.object and context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    for obj in context.selected_objects:
        obj.select_set(False)
    arm.select_set(True)
    context.view_layer.objects.active = arm
    bpy.ops.object.mode_set(mode='EDIT')
    try:
        control = arm.data.edit_bones.new(name)
        control.head = head
        control.tail = head + Vector((0, 0, 0.15))
        control.use_deform = False
        if head_bone:
            control.parent = arm.data.edit_bones.get(head_bone.name)
    finally:
        bpy.ops.object.mode_set(mode='OBJECT')
        for obj in list(context.selected_objects):
            obj.select_set(False)
        for obj in old_selected:
            if obj and bpy.data.objects.get(obj.name):
                obj.select_set(True)
        if old_active and bpy.data.objects.get(old_active.name):
            context.view_layer.objects.active = old_active
    return name


def _model_collections(context, arm):
    rig_settings = getattr(context.scene, "sfm_rigify", None)
    related_arms = {arm}
    if rig_settings:
        for candidate in (rig_settings.source, rig_settings.rig):
            if candidate and candidate.type == 'ARMATURE':
                related_arms.add(candidate)
    related_objects = set()
    for obj in context.scene.objects:
        if obj.type == 'ARMATURE':
            continue
        parent = obj
        while parent is not None:
            if parent in related_arms:
                related_objects.add(obj)
                break
            parent = parent.parent
        if any(mod.type == 'ARMATURE' and mod.object in related_arms for mod in obj.modifiers):
            related_objects.add(obj)
    candidates = {collection for obj in related_objects for collection in obj.users_collection}
    groups = []
    for collection in candidates:
        direct = any(obj in related_objects for obj in collection.objects)
        child_has_model_objects = any(
            any(obj in related_objects for obj in child.all_objects)
            for child in collection.children)
        if direct and not child_has_model_objects:
            groups.append(collection)
    return sorted(groups or candidates, key=lambda collection: collection.name.lower())


def _collection_prop_name(collection):
    clean = re.sub(r"[^A-Za-z0-9_]+", "_", collection.name).strip("_") or "Group"
    digest = hashlib.sha1(collection.name.encode("utf-8")).hexdigest()[:6]
    return f"show_{clean[:38]}_{digest}"


def create_all_group_switches(context, arm):
    if not arm or arm.type != 'ARMATURE':
        raise ValueError("Choose the SFM or Rigify armature first")
    groups = _model_collections(context, arm)
    if not groups:
        raise ValueError("No model collections found for this skeleton")
    bone_name = _groups_control_bone(context, arm)
    bone = arm.pose.bones.get(bone_name)
    if bone is None:
        raise ValueError("Could not create the group control bone")
    for collection in groups:
        prop = _collection_prop_name(collection)
        bone[prop] = 1
        bone.id_properties_ui(prop).update(
            min=0, max=1, soft_min=0, soft_max=1,
            description=f"Show or hide collection: {collection.name}")
        for path in ("hide_viewport", "hide_render"):
            try:
                collection.driver_remove(path)
            except Exception:
                pass
            driver = collection.driver_add(path).driver
            var = driver.variables.new()
            var.name = "visible"
            var.targets[0].id = arm
            var.targets[0].data_path = f'pose.bones["{bone_name}"]["{prop}"]'
            driver.expression = "visible < 0.5"
    return bone_name, len(groups)


class SFMObjectSwitchCreate(bpy.types.Operator):
    bl_idname = "sfm_objectswitch.create"
    bl_label = "Create Outfit / Item Switch"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.sfm_objectswitch
        arm = selected_armature(context, settings)
        try:
            if settings.mode == 'ATTACH':
                count = attach_collection(context, settings.collection, arm, settings.bone)
                action = "attached object(s) to"
            else:
                count = create_switch(context, settings.collection, arm,
                                      settings.bone, settings.property_name,
                                      settings.create_bone)
                action = "switch states on"
        except (ValueError, RuntimeError) as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, f"Processed {count} {action} {settings.bone}")
        return {'FINISHED'}


class SFMObjectSwitchAllGroups(bpy.types.Operator):
    bl_idname = "sfm_objectswitch.groups_to_bone"
    bl_label = "Groups to Bone"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Create one visibility slider per model collection on a control bone above the head"

    def execute(self, context):
        settings = context.scene.sfm_objectswitch
        arm = selected_armature(context, settings)
        try:
            bone, count = create_all_group_switches(context, arm)
        except (ValueError, RuntimeError) as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        self.report({'INFO'}, f"Created {count} collection switches on '{bone}'")
        return {'FINISHED'}


def draw(layout, context):
    settings = context.scene.sfm_objectswitch
    box = layout.box()
    box.label(text="Clothing & Items", icon='OUTLINER_COLLECTION')
    box.prop(settings, "collection")
    box.prop(settings, "skeleton", expand=True)
    arm = selected_armature(context, settings)
    if settings.skeleton == 'CUSTOM':
        box.prop(settings, "armature")
    elif arm:
        box.label(text=f"Target: {arm.name}", icon='ARMATURE_DATA')
    else:
        box.label(text="Selected skeleton is not available yet", icon='ERROR')
    box.prop(settings, "mode", expand=True)
    row = box.row(align=True)
    row.prop(settings, "bone")
    if settings.mode == 'SWITCH':
        row.prop(settings, "property_name")
        box.prop(settings, "create_bone")
    box.operator("sfm_objectswitch.create", text=("Attach Collection" if settings.mode == 'ATTACH'
        else "Create Switch"), icon='BONE_DATA')


CLASSES = (SFMObjectSwitchSettings, SFMObjectSwitchCreate, SFMObjectSwitchAllGroups)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.sfm_objectswitch = PointerProperty(type=SFMObjectSwitchSettings)


def unregister():
    if hasattr(bpy.types.Scene, "sfm_objectswitch"):
        del bpy.types.Scene.sfm_objectswitch
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)
