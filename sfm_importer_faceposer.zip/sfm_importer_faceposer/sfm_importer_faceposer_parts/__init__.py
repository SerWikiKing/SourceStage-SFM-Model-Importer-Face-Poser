"""Optional, separated modules used by the SFM Import / Face Poser add-on."""
