bl_info = {
    "name": "SFM Model Importer + Rigify + Face Poser",
    "author": "SerWiKing",
    "version": (0, 4, 0),
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar (N) > SFM Import",
    "description": "Browse a folder of Source models, preview and import them via SourceIO "
                   "(plain SFM rig or Rigify IK/FK), Eye Fix, bone visibility chooser, "
                   "and the Advanced Face Poser with Source HWM flex support below",
    "category": "Import-Export",
}

# Requirements
#   * SourceIO (provides sourceio.mdl) - imports compiled .mdl models and,
#     with "Import HWM flexes" enabled below, their compiled HWM flex rules
#   * Blender Source Tools - only if you tick "Also list QC / SMD / DMX"
#   * Rigify (bundled with Blender) - enabled automatically
#
# Panels (N sidebar > "SFM Import"), top to bottom:
#   Model Importer          - pick a folder, preview, import (SFM rig or Rigify), Eye Fix
#   Rigify Existing Model   - convert an armature that is already in the scene,
#                             Eye Fix, bone keep/hide chooser
#   Face Poser              - Advanced Face Poser (shape keys / Source HWM flex controls)
#
# NOTE: this single file replaces BOTH sfm_model_importer.py and
# advanced_face_poser_object_switch_pro_fixed.py (and the old sfm_to_rigify.py)
# - disable/remove those add-ons first.

import math
import os
import re
import struct
import json
import hashlib

import numpy as np
import bpy
import bpy.utils.previews
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty,
                       IntProperty, PointerProperty, StringProperty)
from mathutils import Matrix, Vector
from mathutils.kdtree import KDTree
from bpy_extras.io_utils import ExportHelper, ImportHelper
try:
    from .sfm_importer_faceposer_parts.sfm_import import object_switch
except ImportError:  # Also allow the legacy single-file add-on to load beside its module folder.
    from sfm_importer_faceposer_parts.sfm_import import object_switch

PREVIEW_SIZE = 320
BG_COLOR = (0.13, 0.13, 0.14, 1.0)
MAX_PREVIEW_TRIS = 35000
SKIP_DIRS = {"anim", "anims", "animation", "animations", "sequences", "seq"}

# ----------------------------------------------------------------------------
# Part 1: Source armature -> Rigify converter
# ----------------------------------------------------------------------------

SPINE_META = ["spine", "spine.001", "spine.002", "spine.003",
              "spine.004", "spine.005", "spine.006"]
FINGERS = ("thumb", "index", "middle", "ring", "pinky")
LIMB_BONES = ("upper_arm", "forearm", "hand", "thigh", "shin", "foot")

CON_PREFIX = "SFM_"          # constraint names on the source armature
HELPER_PREFIX = "SFM-"       # helper bones created inside the Rigify rig
LINK_COLLECTION = "SFM Link"  # (hidden) bone collection for helper bones


class ConvertError(Exception):
    pass


class _RigifyFailed(Exception):
    pass


# ----------------------------------------------------------------------------
# Bone name presets
#
# Names are normalised (lowercase, alphanumerics only, "valvebiped" prefix
# stripped) so "ValveBiped.Bip01_L_UpperArm" -> "bip01lupperarm" and
# "bip_upperArm_L" -> "bipupperarml".
# To support another skeleton, add a branch in build_preset().
# ----------------------------------------------------------------------------

def norm(name):
    n = "".join(c for c in name.lower() if c.isalnum())
    if n.startswith("valvebiped"):
        n = n[len("valvebiped"):]
    return n


def finger_meta(finger, i, side):
    if finger == "thumb":
        return f"thumb.{i:02d}.{side}"
    return f"f_{finger}.{i:02d}.{side}"


def build_preset(preset):
    """Return (spine_chain, {metarig_bone: normalised_source_name})."""
    m = {}
    if preset == 'VALVE':
        spine = ["bip01pelvis", "bip01spine", "bip01spine1", "bip01spine2",
                 "bip01spine4", "bip01neck1", "bip01head1"]
        fids = {"thumb": ("0", "01", "02"), "index": ("1", "11", "12"),
                "middle": ("2", "21", "22"), "ring": ("3", "31", "32"),
                "pinky": ("4", "41", "42")}
        for side in "LR":
            s = side.lower()
            m[f"shoulder.{side}"] = f"bip01{s}clavicle"
            m[f"upper_arm.{side}"] = f"bip01{s}upperarm"
            m[f"forearm.{side}"] = f"bip01{s}forearm"
            m[f"hand.{side}"] = f"bip01{s}hand"
            m[f"thigh.{side}"] = f"bip01{s}thigh"
            m[f"shin.{side}"] = f"bip01{s}calf"
            m[f"foot.{side}"] = f"bip01{s}foot"
            m[f"toe.{side}"] = f"bip01{s}toe0"
            for f, ids in fids.items():
                for i, fid in enumerate(ids, 1):
                    m[finger_meta(f, i, side)] = f"bip01{s}finger{fid}"
    else:  # 'TF2'  (bip_pelvis, bip_spine_0, bip_hand_L ...)
        spine = ["bippelvis", "bipspine0", "bipspine1", "bipspine2",
                 "bipspine3", "bipneck", "biphead"]
        for side in "LR":
            s = side.lower()
            m[f"shoulder.{side}"] = f"bipcollar{s}"
            m[f"upper_arm.{side}"] = f"bipupperarm{s}"
            m[f"forearm.{side}"] = f"biplowerarm{s}"
            m[f"hand.{side}"] = f"biphand{s}"
            m[f"thigh.{side}"] = f"biphip{s}"
            m[f"shin.{side}"] = f"bipknee{s}"
            m[f"foot.{side}"] = f"bipfoot{s}"
            m[f"toe.{side}"] = f"biptoe{s}"
            for f in FINGERS:
                for i in (1, 2, 3):
                    m[finger_meta(f, i, side)] = f"bip{f}{i - 1}{s}"
    return spine, m


def detect(src, preset):
    """-> (preset_used, {metarig_bone: source_bone}, [spine source bones])"""
    lookup = {norm(b.name): b.name for b in src.data.bones}
    best = None
    for p in (['VALVE', 'TF2'] if preset == 'AUTO' else [preset]):
        spine, m = build_preset(p)
        hits = sum(1 for n in list(m.values()) + spine if n in lookup)
        if best is None or hits > best[0]:
            best = (hits, p, spine, m)
    _, p, spine, m = best
    found = {k: lookup[v] for k, v in m.items() if v in lookup}
    spine_src = [lookup[n] for n in spine if n in lookup]
    return p, found, spine_src


def validate(found, spine_src):
    missing = [f"{b}.{s}" for s in "LR" for b in LIMB_BONES
               if f"{b}.{s}" not in found]
    if len(spine_src) < 4:
        missing.append("spine chain (pelvis ... head)")
    return missing


# ----------------------------------------------------------------------------
# Geometry helpers
# ----------------------------------------------------------------------------

def polyline_point(pts, f):
    lens = [(pts[i + 1] - pts[i]).length for i in range(len(pts) - 1)]
    d = f * sum(lens)
    for i, l in enumerate(lens):
        if d <= l or i == len(lens) - 1:
            return pts[i].lerp(pts[i + 1], min(d / l, 1.0) if l > 1e-9 else 0.0)
        d -= l
    return pts[-1].copy()


def prebend(a, b, c, direction, amount):
    """Push joint b away from the a-c line along `direction` until it is at
    least amount*|ac| off the line (Rigify needs a bend to define IK plane)."""
    line = c - a
    L = line.length
    if L < 1e-9 or amount <= 0.0:
        return b
    ldir = line / L
    dperp = direction - ldir * direction.dot(ldir)
    if dperp.length < 1e-6:
        return b
    dperp.normalize()
    off = (b - a).dot(dperp)
    need = amount * L
    return b + dperp * (need - off) if off < need else b


def find_ground_height(src, origin, up):
    """Lowest point of the meshes bound to `src`, measured along `up`."""
    zmin = None
    for ob in bpy.data.objects:
        if ob.type != 'MESH':
            continue
        bound = ob.parent == src or any(
            m.type == 'ARMATURE' and m.object == src for m in ob.modifiers)
        if not bound:
            continue
        for c in ob.bound_box:
            h = (ob.matrix_world @ Vector(c) - origin).dot(up)
            zmin = h if zmin is None else min(zmin, h)
    return zmin


def compute_frame(src, found, spine_src):
    """Matrix mapping 'Rigify space' -> world.

    Rigify space: character faces -Y, its left side is +X, up is +Z, feet on
    z = 0. The metarig object gets this matrix, so the rig can face any way."""
    mw, bones = src.matrix_world, src.data.bones

    def wh(n):
        return mw @ bones[n].head_local

    pelvis, head = wh(spine_src[0]), wh(spine_src[-1])
    up = Vector((0, 0, 1))
    sd = head - pelvis
    if sd.length > 1e-9 and sd.normalized().dot(up) < 0.95:
        up = sd.normalized()
    left = wh(found["thigh.L"]) - wh(found["thigh.R"])
    left -= up * left.dot(up)
    if left.length < 1e-9:
        raise ConvertError("Cannot determine the character's left/right axis.")
    left.normalize()
    fwd = left.cross(up)
    frame = Matrix((left, -fwd, up)).transposed().to_4x4()

    ground = find_ground_height(src, pelvis, up)
    if ground is None:
        foot_h = min((wh(found[f"foot.{s}"]) - pelvis).dot(up) for s in "LR")
        ground = foot_h - 0.1 * sd.length
    origin = pelvis + up * ground
    return Matrix.Translation(origin) @ frame


def compute_targets(src, found, spine_src, tmpl, T, bend, head_dir='FORWARD'):
    """Head/tail (in Rigify space) for every metarig bone we keep."""
    Tinv = T.inverted()
    mw, bones = src.matrix_world, src.data.bones

    def H(n):
        return Tinv @ (mw @ bones[n].head_local)

    def Tl(n):
        return Tinv @ (mw @ bones[n].tail_local)

    t = {}

    # --- spine / neck / head -------------------------------------------------
    heads = [H(n) for n in spine_src]
    height = max(heads[-1].z, 1e-6)
    tip = Tl(spine_src[-1])
    if head_dir == 'FORWARD':
        # Rigify space: the character faces -Y, so the head bone looks that way
        tip = heads[-1] + Vector((0, -0.10 * height, 0))
    elif not ((tip - heads[-1]).length > 0.02 * height and tip.z > heads[-1].z):
        tip = heads[-1] + Vector((0, 0, 0.13 * height))
    # Source chains end with  ... torso bones, neck, head.  Rigify wants
    # 4 torso bones (spine..spine.003), 2 neck bones (.004/.005) and the head
    # (.006), so: neck base = neck bone head, skull base = head bone head, and the
    # torso is everything from the pelvis up to the neck base (resampled to 4
    # bones when the source has a different number of torso bones, e.g. HL2).
    neck_base, skull = heads[-2], heads[-1]
    torso = heads[:-1]
    if len(torso) == 5:
        torso5 = torso
    else:
        tp = [tmpl[n][0] for n in SPINE_META[:4]] + [tmpl["spine.004"][0]]
        acc = [0.0]
        for i in range(len(tp) - 1):
            acc.append(acc[-1] + (tp[i + 1] - tp[i]).length)
        torso5 = [polyline_point(torso, a / acc[-1]) for a in acc]
    tn = [tmpl[n][0] for n in ("spine.004", "spine.005", "spine.006")]
    f = (tn[1] - tn[0]).length / max((tn[2] - tn[0]).length, 1e-9)
    rp = torso5 + [neck_base.lerp(skull, f), skull, tip]
    for i, n in enumerate(SPINE_META):
        t[n] = (rp[i], rp[i + 1])

    for S in "LR":
        # --- arm -----------------------------------------------------------
        ua = H(found[f"upper_arm.{S}"])
        fa = H(found[f"forearm.{S}"])
        hd = H(found[f"hand.{S}"])
        fa = prebend(ua, fa, hd, Vector((0, 1, 0)), bend)   # elbow points back

        chains = {}
        for f in FINGERS:
            names = [found.get(finger_meta(f, i, S)) for i in (1, 2, 3)]
            if all(names):
                hs = [H(n) for n in names]
                chains[f] = hs + [hs[2] + (hs[2] - hs[1]) * 0.8]

        if f"shoulder.{S}" in found:
            t[f"shoulder.{S}"] = (H(found[f"shoulder.{S}"]), ua)
        t[f"upper_arm.{S}"] = (ua, fa)
        t[f"forearm.{S}"] = (fa, hd)
        mid = chains.get("middle")
        hand_tip = mid[0] if mid else Tl(found[f"hand.{S}"])
        if (hand_tip - hd).length < 1e-6:
            hand_tip = hd + (hd - fa) * 0.3
        t[f"hand.{S}"] = (hd, hand_tip)
        for f, p in chains.items():
            for i in range(3):
                t[finger_meta(f, i + 1, S)] = (p[i], p[i + 1])

        # --- leg -----------------------------------------------------------
        th = H(found[f"thigh.{S}"])
        sh = H(found[f"shin.{S}"])
        ft = H(found[f"foot.{S}"])
        sh = prebend(th, sh, ft, Vector((0, -1, 0)), bend)  # knee points forward
        if f"toe.{S}" in found:
            toe = H(found[f"toe.{S}"])
        else:
            toe = Vector((ft.x, ft.y - 0.10 * height, min(ft.z, 0.03 * height)))
        d = Vector((toe.x - ft.x, toe.y - ft.y, 0.0))
        if d.length < 1e-6:
            d = Vector((0, -0.1 * height, 0))
        tip = toe + d.normalized() * max(d.length * 0.5, 0.02 * height)
        tip.z = toe.z
        t[f"thigh.{S}"] = (th, sh)
        t[f"shin.{S}"] = (sh, ft)
        t[f"foot.{S}"] = (ft, toe)
        t[f"toe.{S}"] = (toe, tip)

        # heel marker: copy the template's layout, scaled to this foot's length
        tf_h, tf_t = tmpl[f"foot.{S}"][0], tmpl[f"foot.{S}"][1]
        tl = Vector((tf_t.x - tf_h.x, tf_t.y - tf_h.y, 0)).length
        k = d.length / tl if tl > 1e-6 else 1.0

        def conv(p, ft=ft, tf_h=tf_h, k=k):
            return Vector((ft.x + k * (p.x - tf_h.x),
                           ft.y + k * (p.y - tf_h.y),
                           k * p.z))

        hh, ht = tmpl[f"heel.02.{S}"][0], tmpl[f"heel.02.{S}"][1]
        t[f"heel.02.{S}"] = (conv(hh), conv(ht))
    return t


def chain_links(keep):
    """(parent, child) pairs that Rigify needs as connected chains."""
    # torso (spine..spine.003) and neck/head (spine.004..spine.006) are two
    # separate chains; spine.003 -> spine.004 stays unconnected like the template
    links = (list(zip(SPINE_META[:3], SPINE_META[1:4]))
             + list(zip(SPINE_META[4:6], SPINE_META[5:7])))
    for S in "LR":
        for chain in ([f"upper_arm.{S}", f"forearm.{S}", f"hand.{S}"],
                      [f"thigh.{S}", f"shin.{S}", f"foot.{S}", f"toe.{S}"],
                      *[[finger_meta(f, i, S) for i in (1, 2, 3)] for f in FINGERS]):
            links += list(zip(chain[:-1], chain[1:]))
    return [(a, b) for a, b in links if a in keep and b in keep]


def fit_bone(eb, head, tail, basis):
    """Place an edit bone, keeping the template's twist relative to its new
    direction (so Rigify's bend planes / rotation axes stay sensible)."""
    if (tail - head).length < 1e-6:
        tail = head + Vector((0, 0, 1e-3))
    d_new = (tail - head).normalized()
    q = basis.col[1].copy().rotation_difference(d_new)
    z_axis = (q.to_matrix() @ basis).col[2].copy()
    eb.head = head
    eb.tail = tail
    eb.align_roll(z_axis)


# ----------------------------------------------------------------------------
# Blender plumbing
# ----------------------------------------------------------------------------

def ensure_rigify():
    if "rigify" not in bpy.context.preferences.addons:
        try:
            bpy.ops.preferences.addon_enable(module="rigify")
        except Exception:
            pass
    if not hasattr(bpy.ops.object, "armature_human_metarig_add"):
        raise ConvertError("The Rigify add-on is not enabled "
                           "(Preferences > Add-ons > Rigify).")


def to_object_mode():
    ob = bpy.context.object
    if ob is not None and ob.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')


def activate(context, obj):
    for o in context.view_layer.objects:
        try:
            o.select_set(False)
        except Exception:
            pass
    try:
        obj.hide_set(False)
    except Exception:
        pass
    obj.select_set(True)
    context.view_layer.objects.active = obj


def build_metarig(context, src, settings):
    ensure_rigify()
    preset, found, spine_src = detect(src, settings.preset)
    missing = validate(found, spine_src)
    if missing:
        raise ConvertError("Could not find these bones in '%s' (preset %s): %s"
                           % (src.name, preset, ", ".join(missing)))

    to_object_mode()
    bpy.ops.object.armature_human_metarig_add()
    meta = context.active_object
    meta.matrix_world = Matrix.Identity(4)
    meta.name = meta.data.name = f"{src.name}_metarig"

    bpy.ops.object.mode_set(mode='EDIT')
    eb = meta.data.edit_bones
    tmpl = {b.name: (b.head.copy(), b.tail.copy(),
                     b.matrix.to_3x3().normalized(),
                     b.parent.name if b.parent else None,
                     b.use_connect) for b in eb}
    need = set(SPINE_META) | {f"{b}.{s}" for s in "LR"
                              for b in LIMB_BONES + ("toe", "heel.02")}
    lacking = sorted(n for n in need if n not in tmpl)
    if lacking:
        bpy.ops.object.mode_set(mode='OBJECT')
        raise ConvertError("This Rigify human metarig has no bones: "
                           + ", ".join(lacking))

    T = compute_frame(src, found, spine_src)
    targets = compute_targets(src, found, spine_src, tmpl, T, settings.bend,
                              settings.head_dir)
    keep = set(targets)

    # disconnect everything, then re-parent to nearest surviving ancestor
    for b in eb:
        b.use_connect = False
    for name in keep:
        anc = tmpl[name][3]
        while anc is not None and anc not in keep:
            anc = tmpl[anc][3]
        eb[name].parent = eb[anc] if anc else None

    for name, (head, tail) in targets.items():
        fit_bone(eb[name], head, tail, tmpl[name][2])

    for name in list(tmpl):            # palms, breasts, pelvis.L/R, face ...
        if name not in keep:
            eb.remove(eb[name])

    for a, c in chain_links(keep):     # Rigify needs these as connected chains
        eb[c].parent = eb[a]
        eb[c].use_connect = True       # snaps child head to parent tail

    for name in keep:                  # restore other template connections
        b = eb[name]
        p = b.parent
        if (p is not None and tmpl[name][4] and tmpl[name][3] == p.name
                and (b.head - p.tail).length <= 1e-4 * max(b.length, 1e-9)):
            b.use_connect = True

    bpy.ops.object.mode_set(mode='OBJECT')

    # single bone per limb segment, like the Source skeleton
    for S in "LR":
        for n in (f"upper_arm.{S}", f"thigh.{S}"):
            try:
                meta.pose.bones[n].rigify_parameters.segments = 1
            except Exception:
                pass

    meta.matrix_world = T
    settings.metarig = meta
    return meta


def generate_rig(context, meta):
    to_object_mode()
    activate(context, meta)
    def run():
        try:
            bpy.ops.pose.rigify_generate()
        except RuntimeError as e:
            raise _RigifyFailed(str(e))

    try:
        run()
    except _RigifyFailed as e:
        if "poll()" not in str(e):
            raise ConvertError(str(e).replace("Error: ", "", 1))
        bpy.ops.object.mode_set(mode='POSE')    # poll failed in object mode
        try:
            run()
        except _RigifyFailed as e2:
            raise ConvertError(str(e2).replace("Error: ", "", 1))
        finally:
            to_object_mode()
    rig = getattr(meta.data, "rigify_target_rig", None)
    if rig is None:
        raise ConvertError("Rigify did not produce a rig - check the "
                           "Info editor / system console for its error.")
    # Rigify bakes the metarig's transform into the bones but leaves the new rig
    # object at its own (identity) transform - put it where the metarig is.
    # (Rigify keeps this matrix on later regenerations.)
    rig.matrix_world = meta.matrix_world.copy()
    return rig


def unlink(src, rig):
    for pb in src.pose.bones:
        for c in list(pb.constraints):
            if c.name.startswith(CON_PREFIX):
                pb.constraints.remove(c)
    if rig is None:
        return
    to_object_mode()
    activate(bpy.context, rig)
    bpy.ops.object.mode_set(mode='EDIT')
    ebs = rig.data.edit_bones
    for b in [b for b in ebs if b.name.startswith(HELPER_PREFIX)]:
        ebs.remove(b)
    bpy.ops.object.mode_set(mode='OBJECT')


def link_source(context, src, rig, settings):
    """Drive the original (deforming) skeleton from the Rigify DEF bones.

    For every mapped source bone a helper bone is created in the rig with the
    source bone's exact rest matrix, parented to the matching DEF bone. The
    source bone then copies rotation+location from the helper, so it is at
    identity in rest pose regardless of any roll/orientation difference.
    (Rotation+location only, so object scale on the source armature is fine.)"""
    preset, found, spine_src = detect(src, settings.preset)
    defs = rig.data.bones
    mw_rig = rig.matrix_world

    pairs, skipped = {}, []
    spine_defs = [d for d in ("DEF-" + s for s in SPINE_META) if d in defs]
    for sn in spine_src:
        h = src.matrix_world @ src.data.bones[sn].head_local
        pairs[sn] = min(spine_defs,
                        key=lambda d: (mw_rig @ defs[d].head_local - h).length)
    for meta_name, sn in found.items():
        d = "DEF-" + meta_name
        if d in defs:
            pairs[sn] = d
        else:
            skipped.append(meta_name)
    if "root" in defs:  # unparented, unmapped source bones follow the root
        for b in src.data.bones:
            if b.parent is None and b.name not in pairs:
                pairs[b.name] = "root"

    unlink(src, rig)
    to_object_mode()
    activate(context, rig)
    bpy.ops.object.mode_set(mode='EDIT')
    ebs = rig.data.edit_bones
    coll = rig.data.collections.get(LINK_COLLECTION) \
        or rig.data.collections.new(LINK_COLLECTION)
    coll.is_visible = False
    Minv = mw_rig.inverted()
    scale = src.matrix_world.to_scale().x / max(mw_rig.to_scale().x, 1e-9)
    made = {}
    for sn, target in pairs.items():
        if target not in ebs:
            continue
        sb = src.data.bones[sn]
        M = Minv @ src.matrix_world @ sb.matrix_local
        rot = M.to_3x3().normalized()
        loc = M.to_translation()
        length = max(sb.length * scale, 1e-4)
        eb = ebs.new(HELPER_PREFIX + sn)
        eb.head = loc
        eb.tail = loc + rot.col[1] * length
        eb.align_roll(rot.col[2])
        eb.parent = ebs[target]
        eb.use_connect = False
        eb.use_deform = False
        for c in list(eb.collections):
            c.unassign(eb)
        coll.assign(eb)
        made[sn] = eb.name
    bpy.ops.object.mode_set(mode='OBJECT')

    for sn, helper in made.items():
        pb = src.pose.bones[sn]
        for kind, name in (('COPY_ROTATION', "Rot"), ('COPY_LOCATION', "Loc")):
            c = pb.constraints.new(kind)
            c.name = CON_PREFIX + name
            c.target = rig
            c.subtarget = helper
            c.target_space = 'WORLD'
            c.owner_space = 'WORLD'

    if settings.ik_default:
        for pb in rig.pose.bones:
            if "IK_FK" in pb.keys():
                pb["IK_FK"] = 0.0      # Rigify: 0.0 = IK, 1.0 = FK
    if settings.hide_source:
        try:
            src.hide_set(True)
        except Exception:
            pass
    activate(context, rig)
    return len(made), skipped


def get_rig(settings):
    if settings.rig:
        return settings.rig
    if settings.metarig:
        return getattr(settings.metarig.data, "rigify_target_rig", None)
    return None




# ----------------------------------------------------------------------------
# Eye Fix
#
#   * adds an "eyetarget" bone to the rig (parented to the head bone)
#   * creates an Empty parented to that bone
#   * makes the eye objects (eye_0 / eye_1 ... empties made by SourceIO) track
#     that Empty with a Damped Track constraint
#
# Re-running it updates everything in place; "Remove" undoes it.
# NOTE: regenerating the Rigify rig deletes the bone - just press Eye Fix again.
# ----------------------------------------------------------------------------

EYE_BONE = "eyetarget"
EYE_CON = "SFM_EyeFix"
EYE_COLLECTION = "Eye Target"
_EYE_RE = re.compile(r"^eye[_\s\-]?(\d+)(?:\.\d+)?$", re.IGNORECASE)
_EYE_SHADER_MARKER = "sfm_stable_eye_shader"
_EYE_MATERIAL_RE = re.compile(
    r"(?:^|[^a-z])(eyerefract|eyes?|eyeball|iris|cornea|pupil)(?:[^a-z]|$)", re.IGNORECASE)


def _char_frame(s, src, rig):
    """(origin, 3x3 rotation) of the character: forward = -Y, up = +Z, left = +X."""
    if rig is not None:
        loc, rot, _ = rig.matrix_world.decompose()
        return loc, rot.to_matrix()
    try:
        _, found, spine = detect(src, s.preset)
        T = compute_frame(src, found, spine)
        return T.to_translation(), T.to_3x3().normalized()
    except Exception:
        return Vector((0, 0, 0)), Matrix.Identity(3)


def head_bone_of(arm, s, src):
    bones = arm.data.bones
    rigify_names = ("head", "ORG-spine.006", "DEF-spine.006")
    if src is not None and arm == src:
        try:
            _, _, spine = detect(src, s.preset)
            if spine and spine[-1] in bones:
                return spine[-1]
        except Exception:
            pass
    for n in rigify_names:
        if n in bones:
            return n
    for b in bones:
        n = norm(b.name)
        if n in ("bip01head1", "biphead"):
            return b.name
    return None


def find_eyes(s, arms, ref_pos):
    manual = [o for o in (s.eye_left, s.eye_right) if o is not None]
    if manual:
        return manual
    best = {}
    for o in bpy.data.objects:
        if o.type != 'EMPTY':
            continue
        m = _EYE_RE.match(o.name)
        if not m:
            continue
        rel = 0
        if o.parent is not None and o.parent in arms:
            rel = 1
        else:
            for c in o.constraints:
                if getattr(c, "target", None) in arms:
                    rel = 1
                    break
        key = (-rel, (o.matrix_world.translation - ref_pos).length)
        idx = int(m.group(1))
        if idx not in best or key < best[idx][0]:
            best[idx] = (key, o)
    return [best[i][1] for i in sorted(best)][:2]


def _eye_widget(arm):
    name = "WGT-" + EYE_BONE
    ob = bpy.data.objects.get(name)
    if ob is None:
        n = 32
        verts = [(0.5 * math.cos(2 * math.pi * i / n),
                  0.5 + 0.5 * math.sin(2 * math.pi * i / n), 0.0) for i in range(n)]
        edges = [(i, (i + 1) % n) for i in range(n)]
        k = len(verts)
        verts += [(-0.18, 0.5, 0.0), (0.18, 0.5, 0.0), (0.0, 0.32, 0.0), (0.0, 0.68, 0.0)]
        edges += [(k, k + 1), (k + 2, k + 3)]
        me = bpy.data.meshes.new(name)
        me.from_pydata(verts, edges, [])
        me.update()
        ob = bpy.data.objects.new(name, me)
    coll = bpy.data.collections.get("WGTS_" + arm.name)
    if coll is not None and ob.name not in coll.objects:
        coll.objects.link(ob)
    return ob


def eye_target_name(arm):
    return f"{arm.name}_{EYE_BONE}"


def eye_fix(context, s):
    """-> (number of eyes constrained, target empty)"""
    src = s.source if (s.source and s.source.type == 'ARMATURE') else None
    rig = get_rig(s)
    arm = rig or src
    if arm is None:
        raise ConvertError("Pick a source armature (or generate a rig) first.")
    hn = head_bone_of(arm, s, src)
    if hn is None:
        raise ConvertError("Could not find the head bone in '%s'." % arm.name)

    context.view_layer.update()
    head_pos = arm.matrix_world @ arm.data.bones[hn].head_local
    arms = [o for o in (src, rig) if o is not None]
    eyes = find_eyes(s, arms, head_pos)
    if not eyes:
        raise ConvertError("No eye objects found (looking for empties named eye_0, "
                           "eye_1 ...). Pick them in the Eye Fix box (Eye L / Eye R).")

    origin, rot = _char_frame(s, src, rig)
    fwd = (rot @ Vector((0, -1, 0))).normalized()
    up = (rot @ Vector((0, 0, 1))).normalized()
    pts = [o.matrix_world.translation.copy() for o in eyes]
    mid = sum(pts, Vector((0, 0, 0))) / len(pts)
    eye_h = max((mid - origin).dot(up), 1e-3)
    spacing = (pts[0] - pts[1]).length if len(pts) > 1 else 0.0
    if spacing < 1e-5:
        spacing = 0.04 * eye_h
    dist = s.eye_distance if s.eye_distance > 1e-6 else 0.35 * eye_h
    size = 2.0 * spacing
    target = mid + fwd * dist

    # --- the bone (child of the head bone) ---------------------------------
    to_object_mode()
    activate(context, arm)
    bpy.ops.object.mode_set(mode='EDIT')
    try:
        ebs = arm.data.edit_bones
        eb = ebs.get(EYE_BONE) or ebs.new(EYE_BONE)
        Minv = arm.matrix_world.inverted()
        R = arm.matrix_world.to_3x3().inverted()
        eb.use_connect = False
        eb.head = Minv @ (target - up * (size / 2))
        eb.tail = Minv @ (target + up * (size / 2))
        eb.align_roll(R @ fwd)
        eb.parent = ebs[hn]
        eb.use_deform = False
        coll = arm.data.collections.get(EYE_COLLECTION) \
            or arm.data.collections.new(EYE_COLLECTION)
        coll.is_visible = True
        for c in list(eb.collections):
            c.unassign(eb)
        coll.assign(eb)
    finally:
        bpy.ops.object.mode_set(mode='OBJECT')

    pb = arm.pose.bones[EYE_BONE]
    pb.custom_shape = _eye_widget(arm)
    bone = arm.data.bones[EYE_BONE]

    # --- the empty (child of the eyetarget bone) ----------------------------
    ename = eye_target_name(arm)
    emp = bpy.data.objects.get(ename)
    if emp is None:
        emp = bpy.data.objects.new(ename, None)
    emp.empty_display_type = 'SPHERE'
    emp.empty_display_size = max(size * 0.12, 1e-4)
    if not emp.users_collection:
        home = arm.users_collection[0] if arm.users_collection else context.scene.collection
        home.objects.link(emp)
    emp.parent = arm
    emp.parent_type = 'BONE'
    emp.parent_bone = EYE_BONE
    emp.matrix_parent_inverse = Matrix.Identity(4)
    # a bone parent's origin is the bone TAIL
    parent_mat = arm.matrix_world @ bone.matrix_local @ Matrix.Translation((0, bone.length, 0))
    emp.matrix_basis = parent_mat.inverted() @ Matrix.Translation(target)

    # --- eyes track the empty ----------------------------------------------
    for o in eyes:
        for c in list(o.constraints):
            if c.name == EYE_CON:
                o.constraints.remove(c)
    context.view_layer.update()
    for o in eyes:
        M = o.matrix_world.to_3x3()
        i = max(range(3), key=lambda k: abs(M.col[k].normalized().dot(fwd)))
        neg = M.col[i].normalized().dot(fwd) < 0
        c = o.constraints.new('DAMPED_TRACK')
        c.name = EYE_CON
        c.target = emp
        c.track_axis = "TRACK_" + ("NEGATIVE_" if neg else "") + "XYZ"[i]
    activate(context, arm)
    return len(eyes), emp


def eye_fix_remove(context, s):
    src = s.source if (s.source and s.source.type == 'ARMATURE') else None
    arm = get_rig(s) or src
    for o in bpy.data.objects:
        for c in list(o.constraints):
            if c.name == EYE_CON:
                o.constraints.remove(c)
    if arm is None:
        return
    emp = bpy.data.objects.get(eye_target_name(arm))
    if emp is not None:
        bpy.data.objects.remove(emp, do_unlink=True)
    if EYE_BONE in arm.data.bones:
        to_object_mode()
        activate(context, arm)
        bpy.ops.object.mode_set(mode='EDIT')
        try:
            arm.data.edit_bones.remove(arm.data.edit_bones[EYE_BONE])
        finally:
            bpy.ops.object.mode_set(mode='OBJECT')


def _try_eye_fix(context, s, op):
    try:
        n, _ = eye_fix(context, s)
        op.report({'INFO'}, f"Eye Fix: {n} eye(s) now follow '{EYE_BONE}'.")
    except ConvertError as e:
        op.report({'WARNING'}, "Eye Fix: %s" % e)


def _source_eye_material(material):
    """Return the untouched SourceIO eye material behind an earlier shader rebuild."""
    if material is None:
        return None
    original_name = material.get("sfm_eye_shader_source")
    if original_name:
        original = bpy.data.materials.get(str(original_name))
        if original is not None:
            return original
    return material


def _is_eye_material(material):
    source = _source_eye_material(material)
    if source is None:
        return False
    shader_name = str(source.get("sourceio_shader", ""))
    return bool(_EYE_MATERIAL_RE.search(f"{source.name} {shader_name}"))


def _walk_shader_nodes(tree, seen=None):
    if tree is None:
        return
    if seen is None:
        seen = set()
    try:
        tree_id = tree.as_pointer()
    except Exception:
        tree_id = id(tree)
    if tree_id in seen:
        return
    seen.add(tree_id)
    for node in tree.nodes:
        yield node
        child_tree = getattr(node, "node_tree", None)
        if child_tree is not None:
            yield from _walk_shader_nodes(child_tree, seen)


def _eye_texture_image(material):
    """Choose a color texture from SourceIO's eye graph, never a cubemap/normal map."""
    if not material.use_nodes or material.node_tree is None:
        return None
    candidates = []
    ignored = ("cubemap", "envmap", "environment", "cornea", "normal", "bump",
               "rough", "ambientoccl", "occlusion", "phong", "specular", "mask")
    for node in _walk_shader_nodes(material.node_tree):
        image = getattr(node, "image", None)
        if image is None:
            continue
        label = " ".join((str(getattr(node, "name", "")),
                          str(getattr(node, "label", "")),
                          str(getattr(image, "name", "")),
                          str(getattr(image, "filepath", "")))).lower()
        if any(word in label for word in ignored):
            continue
        score = 0
        if "iris" in label:
            score += 100
        if "basetexture" in label or "diffuse" in label or "albedo" in label:
            score += 90
        if "eye" in label:
            score += 20
        candidates.append((score, image))
    if not candidates:
        return None
    candidates.sort(key=lambda item: item[0], reverse=True)
    return candidates[0][1]


def _eye_track_axis(eye):
    """The local axis used by the Eye Fix Damped Track constraint."""
    for constraint in eye.constraints:
        if constraint.name == EYE_CON and constraint.type == 'DAMPED_TRACK':
            name = str(constraint.track_axis)
            return "XYZ".index(name[-1])
    return 1  # Source / SFM eyes normally look along their local Y axis.


def _slot_world_vertices(obj, slot_index):
    indices = set()
    for polygon in obj.data.polygons:
        if polygon.material_index == slot_index:
            indices.update(polygon.vertices)
    return [obj.matrix_world @ obj.data.vertices[index].co for index in indices]


def _eye_for_slot(obj, slot_index, eyes):
    if not eyes:
        return None
    points = _slot_world_vertices(obj, slot_index)
    if not points:
        return eyes[0]
    centre = sum(points, Vector()) / len(points)
    return min(eyes, key=lambda eye: (eye.matrix_world.translation - centre).length_squared)


def _eye_projection(obj, slot_index, eye):
    """Find the two tangent axes and radius of one eye material region."""
    forward_axis = _eye_track_axis(eye)
    plane_axes = [axis for axis in range(3) if axis != forward_axis]
    points = _slot_world_vertices(obj, slot_index)
    if not points:
        return plane_axes, 0.01
    inverse = eye.matrix_world.inverted_safe()
    local = [inverse @ point for point in points]
    radius = max(max(abs(point[axis]) for point in local) for axis in plane_axes)
    return plane_axes, max(radius, 1e-5)


def _new_stable_eye_material(source, eye, plane_axes, radius):
    image = _eye_texture_image(source)
    if image is None:
        return None

    material = source.copy()
    material.name = f"{source.name} | Stable Eye"
    material.use_nodes = True
    material[_EYE_SHADER_MARKER] = True
    material["sfm_eye_shader_source"] = source.name

    nodes = material.node_tree.nodes
    nodes.clear()
    coord = nodes.new("ShaderNodeTexCoord")
    # Object coordinates are evaluated relative to eye_0 / eye_1.  Therefore
    # moving the SFM Eye Fix target turns only the iris, just as in Source.
    coord.object = eye
    coord.label = f"Tracked by {eye.name}"
    coord.location = (-820, 80)
    separate = nodes.new("ShaderNodeSeparateXYZ")
    separate.label = "Eye-local position"
    separate.location = (-620, 80)
    map_u = nodes.new("ShaderNodeMapRange")
    map_u.label = "Iris U"
    map_u.clamp = True
    map_u.location = (-410, 125)
    map_v = nodes.new("ShaderNodeMapRange")
    map_v.label = "Iris V"
    map_v.clamp = True
    map_v.location = (-410, -30)
    for mapper in (map_u, map_v):
        mapper.inputs["From Min"].default_value = -radius
        mapper.inputs["From Max"].default_value = radius
        mapper.inputs["To Min"].default_value = 0.0
        mapper.inputs["To Max"].default_value = 1.0
    combine = nodes.new("ShaderNodeCombineXYZ")
    combine.label = "Tracked iris coordinates"
    combine.location = (-190, 80)
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = image
    tex.interpolation = 'Linear'
    tex.extension = 'CLIP'
    tex.label = "Iris / sclera texture"
    tex.location = (20, 80)
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.label = "SFM-style stable eye"
    bsdf.location = (300, 80)
    bsdf.inputs["Roughness"].default_value = 0.24
    bsdf.inputs["IOR"].default_value = 1.38
    specular = bsdf.inputs.get("Specular IOR Level") or bsdf.inputs.get("Specular")
    if specular is not None:
        specular.default_value = 0.35
    coat = bsdf.inputs.get("Coat Weight") or bsdf.inputs.get("Clearcoat")
    if coat is not None:
        coat.default_value = 0.0

    output = nodes.new("ShaderNodeOutputMaterial")
    output.location = (600, 80)
    links = material.node_tree.links
    links.new(coord.outputs["Object"], separate.inputs["Vector"])
    links.new(separate.outputs[plane_axes[0]], map_u.inputs["Value"])
    links.new(separate.outputs[plane_axes[1]], map_v.inputs["Value"])
    links.new(map_u.outputs["Result"], combine.inputs["X"])
    links.new(map_v.outputs["Result"], combine.inputs["Y"])
    links.new(combine.outputs["Vector"], tex.inputs["Vector"])
    if getattr(image, "channels", 0) >= 4:
        # Iris images often use alpha outside the iris; keep the sclera white
        # instead of turning that area black or transparent.
        mix = nodes.new("ShaderNodeMixRGB")
        mix.blend_type = 'MIX'
        mix.inputs[1].default_value = (0.88, 0.86, 0.80, 1.0)
        mix.location = (-80, -150)
        links.new(tex.outputs["Alpha"], mix.inputs[0])
        links.new(tex.outputs["Color"], mix.inputs[2])
        links.new(mix.outputs["Color"], bsdf.inputs["Base Color"])
    else:
        links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    links.new(bsdf.outputs["BSDF"], output.inputs["Surface"])
    return material


def _eye_shader_target_objects(context, settings):
    selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
    if selected_meshes:
        return selected_meshes

    arm = settings.source if settings.source and settings.source.type == 'ARMATURE' else get_rig(settings)
    if arm is not None:
        related = []
        for obj in context.scene.objects:
            if obj.type != 'MESH':
                continue
            parent = obj
            while parent is not None and parent != arm:
                parent = parent.parent
            has_armature_modifier = any(mod.type == 'ARMATURE' and mod.object == arm
                                        for mod in obj.modifiers)
            if parent == arm or has_armature_modifier:
                related.append(obj)
        if related:
            return related
    return [obj for obj in context.scene.objects if obj.type == 'MESH']


def make_stable_eye_shaders(context, settings):
    """Build per-eye UV-free materials driven by SourceIO's eye tracking empties."""
    changed_slots = 0
    skipped_no_texture = 0
    untracked_slots = 0
    arms = [arm for arm in (settings.source, get_rig(settings))
            if arm is not None and arm.type == 'ARMATURE']
    ref = arms[0].matrix_world.translation if arms else Vector()
    eyes = find_eyes(settings, arms, ref)
    objects = _eye_shader_target_objects(context, settings)
    for obj in objects:
        for slot_index, slot in enumerate(obj.material_slots):
            current = slot.material
            if not _is_eye_material(current):
                continue
            source = _source_eye_material(current)
            eye = _eye_for_slot(obj, slot_index, eyes)
            if eye is None:
                untracked_slots += 1
                continue
            plane_axes, radius = _eye_projection(obj, slot_index, eye)
            replacement = _new_stable_eye_material(source, eye, plane_axes, radius)
            if replacement is None:
                skipped_no_texture += 1
                continue
            # Use an object-level override so other meshes sharing this datablock
            # keep their original SourceIO material unless they are processed too.
            if slot.link == 'DATA':
                slot.link = 'OBJECT'
            slot.material = replacement
            changed_slots += 1
    return changed_slots, skipped_no_texture, untracked_slots


# ----------------------------------------------------------------------------
# Bone visibility: choose which bones stay visible and which are hidden
# ----------------------------------------------------------------------------

_BONE_LOCK = False
_NON_CONTROL = ("DEF-", "ORG-", "MCH-", "VIS-", HELPER_PREFIX)


def _bone_arm(s):
    return s.source if s.bone_target == 'SOURCE' else get_rig(s)


def _show_object(arm):
    try:
        if arm.hide_get():
            arm.hide_set(False)
    except Exception:
        pass


def _bone_keep_update(self, context):
    if _BONE_LOCK:
        return
    arm = _bone_arm(context.scene.sfm_rigify)
    if arm is None or arm.type != 'ARMATURE':
        return
    b = arm.data.bones.get(self.name)
    if b is None:
        return
    b.hide = not self.keep
    if self.keep:
        _show_object(arm)


# ----------------------------------------------------------------------------
# Part 2: model browser / importer
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# Humanoid detection (works on plain bone-name lists)
# ----------------------------------------------------------------------------

_HUMANOID_VALVE = ["bip01pelvis", "bip01head1"] + [
    f"bip01{s}{b}" for s in "lr"
    for b in ("thigh", "calf", "foot", "upperarm", "forearm", "hand")]
_HUMANOID_TF2 = ["bippelvis", "biphead"] + [
    f"bip{b}{s}" for s in "lr"
    for b in ("hip", "knee", "foot", "upperarm", "lowerarm", "hand")]


def is_humanoid(bone_names):
    n = {norm(b) for b in bone_names}
    return all(r in n for r in _HUMANOID_VALVE) or all(r in n for r in _HUMANOID_TF2)


def op_exists(idname):
    cat, name = idname.split(".")
    try:
        getattr(getattr(bpy.ops, cat), name).get_rna_type()
        return True
    except Exception:
        return False


# ----------------------------------------------------------------------------
# Compiled models: MDL (bones, bodyparts) + VVD (vertices) -> preview points
# Layout verified against SourceIO's own readers (studio v44-v49).
# ----------------------------------------------------------------------------

_VVD_VERTEX = np.dtype([("weight", "<f4", 3), ("bone_id", "u1", 3), ("pad", "u1"),
                        ("pos", "<f4", 3), ("normal", "<f4", 3), ("uv", "<f4", 2)])


def _mdl_bone_names(d, count, off):
    for stride in (216, 244):          # sizeof(mstudiobone_t): v44-49 / v53
        names = []
        for i in range(count):
            b = off + i * stride
            if b + 4 > len(d):
                break
            p = b + struct.unpack_from("<i", d, b)[0]
            e = d.find(b"\0", p) if 0 <= p < len(d) else -1
            nm = d[p:e].decode("ascii", "ignore") if e > p else ""
            if not nm or not nm.isprintable():
                break
            names.append(nm)
        else:
            return names
    return []


def parse_mdl(mdl_path):
    """-> (bone_names, [(first_vertex, vertex_count) of the first model of every bodypart])"""
    with open(mdl_path, "rb") as f:
        d = f.read()
    if d[:4] != b"IDST":
        raise ValueError("not a studio MDL")
    version = struct.unpack_from("<i", d, 4)[0]
    if version < 44:
        raise ValueError(f"MDL v{version}: no preview (import may still work)")
    nb, bo = struct.unpack_from("<II", d, 156)
    nbp, bpo = struct.unpack_from("<II", d, 232)
    names = _mdl_bone_names(d, nb, bo)
    models = []
    for i in range(nbp):
        bp = bpo + i * 16               # sznameindex, nummodels, base, modelindex
        nmodels, _base, mindex = struct.unpack_from("<III", d, bp + 4)
        if nmodels > 0:
            nv, vi = struct.unpack_from("<II", d, bp + mindex + 80)
            if nv > 0:
                models.append((vi // 48, nv))
    return names, models


def read_vvd_points(vvd_path, models):
    with open(vvd_path, "rb") as f:
        d = f.read()
    if d[:4] != b"IDSV":
        raise ValueError("not a VVD")
    lodv = struct.unpack_from("<8I", d, 16)
    nfix, fixoff, vdoff, tdoff = struct.unpack_from("<4I", d, 48)
    end = tdoff if tdoff > vdoff else len(d)
    src = np.frombuffer(d, _VVD_VERTEX, count=(end - vdoff) // 48, offset=vdoff)
    if nfix:
        fx = np.frombuffer(d, "<i4", count=nfix * 3, offset=fixoff).reshape(-1, 3)
        parts = [src[s:s + n] for lod, s, n in fx if lod >= 0]
        lod0 = np.concatenate(parts) if parts else src[:lodv[0]]
    else:
        lod0 = src[:lodv[0]]
    sel = [lod0[a:a + n] for a, n in models if a < len(lod0)] or [lod0]
    v = np.concatenate(sel)
    return v["pos"].astype(np.float32), v["normal"].astype(np.float32)


def vtx_exists(mdl_path):
    base = os.path.splitext(mdl_path)[0]
    return any(os.path.isfile(base + s) for s in (".dx90.vtx", ".dx80.vtx", ".sw.vtx", ".vtx"))


# ----------------------------------------------------------------------------
# Decompiled models: SMD / QC (Blender Source Tools path, optional)
# ----------------------------------------------------------------------------

def parse_smd(path):
    """-> (bone_names, V (n*3,3), N (n*3,3)). SMD vertices are already in the
    reference pose, so no skinning is needed for a preview."""
    names, verts, norms = [], [], []
    mode = None
    with open(path, "r", errors="ignore") as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            if mode is None:
                if line in ("nodes", "skeleton", "triangles"):
                    mode = line
                elif line.startswith("vertexanimation"):
                    mode = "skip"
                continue
            if line == "end":
                mode = None
                continue
            if mode == "nodes":
                q1, q2 = line.find('"'), line.rfind('"')
                if q1 >= 0 and q2 > q1:
                    names.append(line[q1 + 1:q2])
            elif mode == "triangles":
                p = line.split()
                if len(p) >= 9 and p[0].lstrip("-").isdigit():
                    try:
                        verts.append((float(p[1]), float(p[2]), float(p[3])))
                        norms.append((float(p[4]), float(p[5]), float(p[6])))
                    except ValueError:
                        pass
    n = len(verts) // 3 * 3
    V = np.array(verts[:n], np.float32).reshape(-1, 3)
    N = np.array(norms[:n], np.float32).reshape(-1, 3)
    return names, V, N


_TOK = re.compile(r'"[^"]*"|\{|\}|[^\s{}"]+')


def _resolve(dirs, name):
    name = name.replace("\\", "/")
    if not os.path.splitext(name)[1]:
        name += ".smd"
    for d in dirs:
        p = os.path.normpath(os.path.join(d, name))
        if os.path.isfile(p):
            return p
    target = os.path.basename(name).lower()
    for root, _, files in os.walk(dirs[0]):
        for f in files:
            if f.lower() == target:
                return os.path.join(root, f)
    return None


def qc_mesh_files(qc_path, depth=0):
    """Reference .smd files of a QC ($body, $model, first option of $bodygroup)."""
    base = os.path.dirname(qc_path)
    dirs = [base]
    found, in_bg, taken = [], False, False
    try:
        with open(qc_path, "r", errors="ignore") as fh:
            lines = fh.read().splitlines()
    except OSError:
        return []
    for raw in lines:
        toks = [t.strip('"') for t in _TOK.findall(raw.split("//")[0])]
        if not toks:
            continue
        key = toks[0].lower()
        if key == "$cd" and len(toks) > 1:
            dirs.insert(0, os.path.normpath(os.path.join(base, toks[1].replace("\\", "/"))))
        elif key in ("$body", "$model") and len(toks) >= 3:
            p = _resolve(dirs, toks[2])
            if p:
                found.append(p)
        elif key == "$bodygroup":
            in_bg, taken = True, False
        elif key == "studio" and in_bg and len(toks) > 1 and not taken:
            taken = True
            p = _resolve(dirs, toks[1])
            if p:
                found.append(p)
        elif toks[0] == "}" and in_bg:
            in_bg = False
        elif key == "$include" and len(toks) > 1 and depth < 2:
            for d in dirs:
                cand = os.path.normpath(os.path.join(d, toks[1].replace("\\", "/")))
                if os.path.isfile(cand):
                    found += qc_mesh_files(cand, depth + 1)
                    break
    seen, out = set(), []
    for p in found:
        if p.lower().endswith(".smd") and p not in seen:
            seen.add(p)
            out.append(p)
    return out


# ----------------------------------------------------------------------------
# Software preview renderer (numpy point splatting, no GPU needed)
# ----------------------------------------------------------------------------

_OFFSETS = {r: [(dx, dy) for dx in range(-r, r + 1) for dy in range(-r, r + 1)] for r in (1, 2, 3)}
_BASE = np.array([0.74, 0.77, 0.82], np.float32)


def _lattice(k):
    w = [(i / k, j / k, (k - i - j) / k) for i in range(k + 1) for j in range(k + 1 - i)]
    return np.array(w, np.float32)


def build_points(V, N, scale, max_points=500000):
    """Sample every triangle on a barycentric lattice dense enough that the
    preview has no holes (k grows with the triangle's size on screen)."""
    n = len(V) // 3
    V = V[:n * 3].reshape(n, 3, 3)
    N = N[:n * 3].reshape(n, 3, 3)
    if n > MAX_PREVIEW_TRIS:
        sel = np.linspace(0, n - 1, MAX_PREVIEW_TRIS).astype(np.int64)
        V, N = V[sel], N[sel]
    edge = np.maximum.reduce([np.linalg.norm(V[:, 0] - V[:, 1], axis=1),
                              np.linalg.norm(V[:, 1] - V[:, 2], axis=1),
                              np.linalg.norm(V[:, 2] - V[:, 0], axis=1)])
    k = np.clip(np.ceil(edge * scale / 1.5), 1, 60).astype(np.int32)
    for _ in range(4):                          # keep the total bounded
        total = int(((k + 1) * (k + 2) // 2).sum())
        if total <= max_points:
            break
        k = np.maximum(1, (k * math.sqrt(max_points / total)).astype(np.int32))
    Ps, Ns = [], []
    for kk in np.unique(k):
        sel = k == kk
        W = _lattice(int(kk))                   # (m, 3)
        Ps.append(np.einsum("mc,tcd->tmd", W, V[sel]).reshape(-1, 3))
        Ns.append(np.einsum("mc,tcd->tmd", W, N[sel]).reshape(-1, 3))
    P, NN = np.concatenate(Ps), np.concatenate(Ns)
    NN = NN / np.maximum(np.linalg.norm(NN, axis=1, keepdims=True), 1e-9)
    return P.astype(np.float32), NN.astype(np.float32)


def fit_info(P):
    lo, hi = P.min(0), P.max(0)
    cxy = (lo[:2] + hi[:2]) * 0.5
    r = float(np.max(np.hypot(P[:, 0] - cxy[0], P[:, 1] - cxy[1])))
    zspan = float(hi[2] - lo[2])
    extent = max(zspan, 2.0 * r * 0.85, 1e-6) * 1.08
    return {"cxy": cxy, "zmid": float((lo[2] + hi[2]) * 0.5), "scale": PREVIEW_SIZE / extent}


def render_preview(info, az_deg, size=PREVIEW_SIZE):
    img = np.empty((size * size, 4), np.float32)
    img[:] = BG_COLOR
    P, N = info.get("P"), info.get("N")
    if P is None or len(P) == 0:
        return img
    fit = info["fit"]
    az = math.radians(az_deg)
    cam = np.array([math.cos(az), math.sin(az), 0.0], np.float32)       # towards camera
    right = np.array([-math.sin(az), math.cos(az), 0.0], np.float32)
    up = np.array([0, 0, 1], np.float32)
    rel = P - np.array([fit["cxy"][0], fit["cxy"][1], 0.0], np.float32)
    px = size * 0.5 + (rel @ right) * fit["scale"]
    py = size * 0.5 + (P[:, 2] - fit["zmid"]) * fit["scale"]
    depth = rel @ cam

    light = cam * 0.65 - right * 0.45 + up * 0.6
    light /= np.linalg.norm(light)
    d = N @ light
    shade = 0.28 + 0.72 * np.clip(d, 0, 1) + 0.12 * np.clip(-d, 0, 1)

    offs = _OFFSETS[info.get("splat", 1)]
    xi = np.rint(px).astype(np.int32)
    yi = np.rint(py).astype(np.int32)
    xs = np.concatenate([xi + dx for dx, _ in offs])
    ys = np.concatenate([yi + dy for _, dy in offs])
    dep = np.tile(depth, len(offs))
    sh = np.tile(shade, len(offs))
    ok = (xs >= 0) & (xs < size) & (ys >= 0) & (ys < size)
    xs, ys, dep, sh = xs[ok], ys[ok], dep[ok], sh[ok]
    order = np.argsort(dep, kind="stable")          # far -> near, near wins
    flat = (ys * size + xs)[order]
    img[flat, :3] = _BASE[None, :] * sh[order][:, None]
    img[flat, 3] = 1.0
    return img


# ----------------------------------------------------------------------------
# Model scanning + per-model cache
# ----------------------------------------------------------------------------

_cache = {}     # path -> info dict
_pcoll = None
_pv = None


def looks_like_mesh_smd(path):
    try:
        with open(path, "rb") as f:
            return b"\ntriangles" in f.read(4 * 1024 * 1024)
    except OSError:
        return False


def scan_folder(root, max_depth, include_decompiled):
    root = os.path.abspath(root)
    mdls, qcs, others, qc_dirs = [], [], [], []
    for cur, dirs, files in os.walk(root):
        depth = cur[len(root):].count(os.sep)
        if depth >= max_depth:
            dirs[:] = []
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            full = os.path.join(cur, f)
            if ext == ".mdl":
                if os.path.isfile(full[:-4] + ".vvd"):   # skip animation-only / include MDLs
                    mdls.append(full)
            elif include_decompiled and ext == ".qc":
                qcs.append(full)
                if cur not in qc_dirs:
                    qc_dirs.append(cur)
            elif include_decompiled and ext in (".smd", ".dmx"):
                others.append(full)

    def under_qc(p):
        return any(p.startswith(d + os.sep) or os.path.dirname(p) == d for d in qc_dirs)

    out = [(p, "MDL") for p in mdls] + [(p, "QC") for p in qcs]
    for p in others:
        if under_qc(p):
            continue
        parts = {x.lower() for x in os.path.dirname(p)[len(root):].split(os.sep)}
        if parts & SKIP_DIRS:
            continue
        if p.lower().endswith(".smd") and not looks_like_mesh_smd(p):
            continue
        out.append((p, p.rsplit(".", 1)[1].upper()))
    out.sort(key=lambda t: t[0].lower())
    return root, out[:5000]


def load_info(path, kind):
    if path in _cache:
        return _cache[path]
    info = {"P": None, "N": None, "fit": None, "humanoid": None, "tris": 0,
            "status": "", "kind": kind, "splat": 1}
    try:
        if kind == "MDL":
            names, models = parse_mdl(path)
            vvd = os.path.splitext(path)[0] + ".vvd"
            P, N = read_vvd_points(vvd, models)
            if names:
                info["humanoid"] = is_humanoid(names)
            if len(P):
                info["fit"] = fit_info(P)
                info["P"], info["N"] = P, N / np.maximum(np.linalg.norm(N, axis=1, keepdims=True), 1e-9)
                info["splat"] = 3 if len(P) < 6000 else 2 if len(P) < 40000 else 1
            info["status"] = f"{len(P):,} vertices, {len(names)} bones"
            if not vtx_exists(path):
                info["status"] += " | .vtx missing: SourceIO cannot import this"
        elif kind == "DMX":
            info["status"] = "DMX: no preview (import still works)"
        else:
            files = qc_mesh_files(path) if kind == "QC" else [path]
            if not files:
                info["status"] = ("No .smd reference meshes found in QC "
                                  "(DMX-based model? import still works)")
            else:
                names, Vs, Ns = [], [], []
                for f in files[:24]:
                    n, V, N = parse_smd(f)
                    if len(n) > len(names):
                        names = n
                    if len(V):
                        Vs.append(V)
                        Ns.append(N)
                if names:
                    info["humanoid"] = is_humanoid(names)
                if Vs:
                    V, N = np.concatenate(Vs), np.concatenate(Ns)
                    info["tris"] = len(V) // 3
                    info["fit"] = fit_info(V)
                    info["P"], info["N"] = build_points(V, N, info["fit"]["scale"])
                    info["status"] = (f"{info['tris']:,} triangles, {len(files)} mesh file(s), "
                                      f"{len(names)} bones")
                else:
                    info["status"] = "No triangles found"
    except Exception as e:  # never break the UI because of a weird file
        info["status"] = f"No preview: {e}"
    _cache[path] = info
    return info


def current_item(s):
    if 0 <= s.index < len(s.models):
        return s.models[s.index]
    return None


def refresh_preview(s):
    if _pv is None:
        return
    item = current_item(s)
    if item is None:
        img = np.empty((PREVIEW_SIZE * PREVIEW_SIZE, 4), np.float32)
        img[:] = BG_COLOR
    else:
        img = render_preview(load_info(item.path, item.kind), math.degrees(s.preview_angle))
    _pv.image_size = (PREVIEW_SIZE, PREVIEW_SIZE)
    _pv.image_pixels_float.foreach_set(img.ravel())
    for w in bpy.context.window_manager.windows:
        for a in w.screen.areas:
            a.tag_redraw()


def _on_select(self, context):
    refresh_preview(self)


def _on_angle(self, context):
    refresh_preview(self)


# ----------------------------------------------------------------------------
# Import back-ends
# ----------------------------------------------------------------------------

class ImportError_(Exception):
    pass


def _new_objects(before):
    return [o for o in bpy.data.objects if o.name not in before]


def run_sourceio_import(path, s):
    if not op_exists("sourceio.mdl"):
        raise ImportError_("The SourceIO add-on is not installed/enabled.")
    props = bpy.ops.sourceio.mdl.get_rna_type().properties
    kw = {"filepath": path}
    if "directory" in props:
        kw["directory"] = os.path.dirname(path) + os.sep
    if "files" in props:
        kw["files"] = [{"name": os.path.basename(path)}]
    # SourceIO already knows how to read HWM flex data from Source MDLs.  It
    # exposes it only when this option is passed to its import operator.
    # Check the RNA properties because older SourceIO builds do not have it.
    for k, v in (("scale", s.scale), ("import_textures", s.import_textures),
                 ("import_animations", s.import_anims),
                 ("create_flex_drivers", s.import_hwm_flexes)):
        if k in props:
            kw[k] = v
    before = {o.name for o in bpy.data.objects}
    flex_drivers_ok = True
    try:
        res = bpy.ops.sourceio.mdl(**kw)
    except RuntimeError as exc:
        # Some SourceIO versions assert that paired HWM controllers have
        # identical ranges. Real MDLs may legitimately use different ranges.
        # Retry the import without SourceIO's optional flex drivers; the mesh
        # and shape keys still import and can be connected through Face Poser.
        if not (kw.get("create_flex_drivers") and "AssertionError" in str(exc)):
            raise
        for obj in _new_objects(before):
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
            except Exception:
                pass
        retry_kw = dict(kw)
        retry_kw["create_flex_drivers"] = False
        try:
            res = bpy.ops.sourceio.mdl(**retry_kw)
        except Exception as retry_exc:
            raise ImportError_("SourceIO failed importing the model even without flex drivers: %s" % retry_exc)
        flex_drivers_ok = False
    new = _new_objects(before)
    if not new:
        raise ImportError_("SourceIO imported nothing (result %s). Missing .vtx/.vvd or "
                           "materials? See the Info editor." % (sorted(res),))
    return new, flex_drivers_ok


def run_source_tools_import(path, s):
    if not op_exists("import_scene.smd"):
        raise ImportError_("Blender Source Tools is not installed/enabled "
                           "(needed for QC/SMD/DMX).")
    props = bpy.ops.import_scene.smd.get_rna_type().properties
    kw = {"filepath": path}
    if "doAnim" in props:
        kw["doAnim"] = s.import_anims
    if "createCollections" in props:
        kw["createCollections"] = s.create_collections
    if "append" in props and "NEW_ARMATURE" in [i.identifier for i in props["append"].enum_items]:
        kw["append"] = 'NEW_ARMATURE'      # never merge into the active armature
    before = {o.name for o in bpy.data.objects}
    res = bpy.ops.import_scene.smd(**kw)
    new = _new_objects(before)
    if not new and 'FINISHED' in res and "directory" in props and "files" in props:
        res = bpy.ops.import_scene.smd(
            directory=os.path.dirname(path) + os.sep,
            files=[{"name": os.path.basename(path)}],
            **{k: v for k, v in kw.items() if k != "filepath"})
        new = _new_objects(before)
    if not new:
        raise ImportError_("Source Tools imported nothing (result: %s)." % (sorted(res),))
    return new


def pick_armature(objs):
    arms = [o for o in objs if o.type == 'ARMATURE']
    return max(arms, key=lambda o: len(o.data.bones)) if arms else None


# ----------------------------------------------------------------------------
# Importer operators
# ----------------------------------------------------------------------------

class SFMIMPORT_OT_scan(bpy.types.Operator):
    bl_idname = "sfm_import.scan"
    bl_label = "Scan Folder"
    bl_description = "Find models in the folder (.mdl with .vvd; optionally QC/SMD/DMX)"

    def execute(self, context):
        s = context.scene.sfm_import
        folder = bpy.path.abspath(s.folder)
        if not os.path.isdir(folder):
            self.report({'ERROR'}, "Folder does not exist.")
            return {'CANCELLED'}
        root, found = scan_folder(folder, s.depth, s.include_decompiled)
        _cache.clear()
        s.models.clear()
        for path, kind in found:
            it = s.models.add()
            it.name = os.path.splitext(os.path.relpath(path, root))[0]
            it.path = path
            it.kind = kind
        s.index = 0 if found else -1
        refresh_preview(s)
        if not found:
            self.report({'WARNING'}, "No models found (a .mdl needs its .vvd/.vtx next to it).")
        else:
            self.report({'INFO'}, f"{len(found)} model(s) found.")
        return {'FINISHED'}


class SFMIMPORT_OT_import(bpy.types.Operator):
    bl_idname = "sfm_import.import_model"
    bl_label = "Import Selected Model"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return current_item(context.scene.sfm_import) is not None

    def execute(self, context):
        s = context.scene.sfm_import
        item = current_item(s)
        info = load_info(item.path, item.kind)
        want_rigify = s.rig_mode == 'RIGIFY' and info["humanoid"] is not False
        try:
            to_object_mode()
            if item.kind == "MDL":
                new, source_flex_drivers_ok = run_sourceio_import(item.path, s)
            else:
                new = run_source_tools_import(item.path, s)
                source_flex_drivers_ok = True
        except ImportError_ as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        arm = pick_armature(new)
        if arm is not None:                 # so Eye Fix / bone chooser work right away
            rs0 = context.scene.sfm_rigify
            rs0.source = arm
            rs0.metarig = None
            rs0.rig = None
            rs0.bone_list.clear()
            context.scene.sfm_objectswitch.armature = arm
        if want_rigify:
            if arm is None:
                self.report({'WARNING'}, "Imported, but the model has no armature to convert.")
                return {'FINISHED'}
            rs = context.scene.sfm_rigify
            try:
                rs.source = arm
                meta = build_metarig(context, arm, rs)
                rig = generate_rig(context, meta)
                rs.rig = rig
                link_source(context, arm, rig, rs)
            except ConvertError as e:
                self.report({'ERROR'}, "Imported with the plain SFM rig, but Rigify conversion "
                                       "failed: %s" % e)
                return {'FINISHED'}
        # Turn SourceIO's HWM controller collection into the same compact
        # Face Poser UI used for ordinary shape-key models.  This preserves
        # SourceIO's flex-rule drivers instead of replacing them.
        hwm_prepared = 0
        fallback_connected = 0
        if item.kind == "MDL" and s.import_hwm_flexes and source_flex_drivers_ok:
            for ob in new:
                if _has_sourceio_flexes(ob):
                    hwm_prepared += setup_hwm_faceposer(ob, context.scene)
        elif item.kind == "MDL" and s.import_hwm_flexes and not source_flex_drivers_ok:
            # SourceIO could not build its corrective-flex evaluator. Keep the
            # imported face usable by connecting the ordinary imported keys.
            for ob in new:
                if ob.type == "MESH" and ob.data.shape_keys:
                    context.view_layer.objects.active = ob
                    try:
                        if bpy.ops.faceposer.connect() == {"FINISHED"}:
                            fallback_connected += 1
                    except Exception:
                        pass

        if arm is not None and context.scene.sfm_rigify.auto_eye_fix:
            _try_eye_fix(context, context.scene.sfm_rigify, self)
        suffix = " with Rigify rig." if want_rigify else "."
        if hwm_prepared:
            suffix += f" HWM Face Poser prepared for {hwm_prepared} mesh(es)."
        elif item.kind == "MDL" and s.import_hwm_flexes and not source_flex_drivers_ok:
            suffix += (" SourceIO rejected unequal paired flex ranges; imported without its corrective flex rules. "
                       f"Face Poser connected shape keys on {fallback_connected} mesh(es).")
        self.report({'INFO'}, f"Imported '{item.name}'" + suffix)
        return {'FINISHED'}


class SFMIMPORT_Item(bpy.types.PropertyGroup):
    path: StringProperty()
    kind: StringProperty()


class SFMIMPORT_Settings(bpy.types.PropertyGroup):
    folder: StringProperty(name="Folder", subtype='DIR_PATH',
                           description="Folder with Source models (searched recursively)")
    depth: IntProperty(name="Depth", default=10, min=1, max=30,
                       description="How many sub-folder levels to scan")
    include_decompiled: BoolProperty(
        name="Also list QC / SMD / DMX", default=False,
        description="Include decompiled models (imported with Blender Source Tools)")
    models: CollectionProperty(type=SFMIMPORT_Item)
    index: IntProperty(default=-1, update=_on_select)
    preview_angle: FloatProperty(name="Rotate", default=0.0, min=0.0, max=math.radians(360),
                                 subtype='ANGLE', unit='ROTATION', update=_on_angle)
    rig_mode: EnumProperty(
        name="Rig", default='SFM',
        items=[('SFM', "SFM rig", "Keep the original Source skeleton"),
               ('RIGIFY', "Rigify (IK/FK)", "Build a Rigify rig on top of it after the import")])
    scale: FloatProperty(name="World scale", default=0.01905, precision=5, min=0.00001,
                         description="SourceIO import scale (0.01905 = Source units to metres)")
    import_textures: BoolProperty(name="Import materials", default=True)
    import_anims: BoolProperty(name="Import animations", default=False,
                               description="Also import the model's sequences (slower)")
    import_hwm_flexes: BoolProperty(
        name="Import HWM flexes",
        default=True,
        description="Ask SourceIO to import Source flex rules/controllers and prepare them for Face Poser")
    create_collections: BoolProperty(name="Create collections", default=True,
                                     description="Source Tools only")


class SFMIMPORT_UL_models(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        ic = {'MDL': 'OUTLINER_OB_ARMATURE', 'QC': 'FILE_SCRIPT'}.get(item.kind, 'MESH_DATA')
        layout.label(text=item.name, icon=ic)


class SFMIMPORT_PT_panel(bpy.types.Panel):
    bl_label = "Model Importer"
    bl_idname = "SFMIMPORT_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SFM Import"

    def draw(self, context):
        s = context.scene.sfm_import
        L = self.layout
        col = L.column(align=True)
        col.prop(s, "folder")
        row = col.row(align=True)
        row.operator("sfm_import.scan", icon='FILE_REFRESH')
        row.prop(s, "depth")
        col.prop(s, "include_decompiled")

        L.template_list("SFMIMPORT_UL_models", "", s, "models", s, "index", rows=7)

        item = current_item(s)
        if item is None:
            L.label(text="Pick a folder and press Scan Folder")
            return
        info = load_info(item.path, item.kind)

        box = L.box()
        if _pv is not None:
            box.template_icon(icon_value=_pv.icon_id, scale=12)
        box.prop(s, "preview_angle", slider=True)
        box.label(text=info["status"])

        if info["humanoid"] is False:
            box.label(text="Not a humanoid skeleton: SFM rig only", icon='INFO')
        else:
            if info["humanoid"]:
                box.label(text="Humanoid skeleton detected", icon='ARMATURE_DATA')
            box.row().prop(s, "rig_mode", expand=True)
            if s.rig_mode == 'RIGIFY':
                r = context.scene.sfm_rigify
                c = box.column(align=True)
                c.prop(r, "bend")
                c.prop(r, "ik_default")
                c.prop(r, "hide_source")
                c.prop(r, "head_dir")
                c.prop(r, "auto_eye_fix")

        c = L.column(align=True)
        if item.kind == "MDL":
            c.prop(s, "scale")
            c.prop(s, "import_textures")
            c.prop(s, "import_hwm_flexes")
        else:
            c.prop(s, "create_collections")
        c.prop(s, "import_anims")
        row = L.row()
        row.operator("sfm_objectswitch.groups_to_bone", text="Groups to Bone", icon='BONE_DATA')
        row = L.row()
        row.scale_y = 1.6
        row.operator("sfm_import.import_model", icon='IMPORT')
        row = L.row()
        row.scale_y = 1.3
        row.operator("sfm_rigify.eye_fix", icon='HIDE_OFF')


class SFMOBJECTSWITCH_PT_panel(bpy.types.Panel):
    bl_label = "Clothing & Items"
    bl_idname = "SFMOBJECTSWITCH_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SFM Import"

    def draw(self, context):
        object_switch.draw(self.layout, context)


# ----------------------------------------------------------------------------
# Part 3: Rigify operators + panel
# ----------------------------------------------------------------------------

class _Base(bpy.types.Operator):
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        s = context.scene.sfm_rigify
        return s.source is not None and s.source.type == 'ARMATURE'


class SFMRIGIFY_OT_build_metarig(_Base):
    bl_idname = "sfm_rigify.build_metarig"
    bl_label = "1. Build Metarig"
    bl_description = "Create a Rigify metarig fitted to the source skeleton"

    def execute(self, context):
        s = context.scene.sfm_rigify
        try:
            meta = build_metarig(context, s.source, s)
        except ConvertError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        self.report({'INFO'}, f"Metarig '{meta.name}' created. Adjust it if "
                              "needed, then press 2. Generate + Link.")
        return {'FINISHED'}


class SFMRIGIFY_OT_generate_link(_Base):
    bl_idname = "sfm_rigify.generate_link"
    bl_label = "2. Generate + Link"
    bl_description = "Run Rigify on the metarig and drive the source skeleton from it"

    @classmethod
    def poll(cls, context):
        s = context.scene.sfm_rigify
        return super().poll(context) and s.metarig is not None

    def execute(self, context):
        s = context.scene.sfm_rigify
        try:
            rig = generate_rig(context, s.metarig)
            s.rig = rig
            n, skipped = link_source(context, s.source, rig, s)
        except ConvertError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        msg = f"Linked {n} bones to '{rig.name}'."
        if skipped:
            msg += " No DEF bone for: " + ", ".join(skipped)
        self.report({'INFO'}, msg)
        if s.auto_eye_fix:
            _try_eye_fix(context, s, self)
        return {'FINISHED'}


class SFMRIGIFY_OT_convert(_Base):
    bl_idname = "sfm_rigify.convert"
    bl_label = "Convert to Rigify"
    bl_description = "Build metarig, generate the Rigify rig and link the source skeleton"

    def execute(self, context):
        s = context.scene.sfm_rigify
        try:
            meta = build_metarig(context, s.source, s)
            rig = generate_rig(context, meta)
            s.rig = rig
            n, skipped = link_source(context, s.source, rig, s)
        except ConvertError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        msg = f"Done: '{rig.name}' drives {n} source bones."
        if skipped:
            msg += " No DEF bone for: " + ", ".join(skipped)
        self.report({'INFO'}, msg)
        if s.auto_eye_fix:
            _try_eye_fix(context, s, self)
        return {'FINISHED'}


class SFMRIGIFY_OT_relink(_Base):
    bl_idname = "sfm_rigify.relink"
    bl_label = "Re-link"
    bl_description = ("Re-create the link between source and rig "
                      "(use after regenerating the rig from the metarig)")

    @classmethod
    def poll(cls, context):
        s = context.scene.sfm_rigify
        return super().poll(context) and get_rig(s) is not None

    def execute(self, context):
        s = context.scene.sfm_rigify
        try:
            n, skipped = link_source(context, s.source, get_rig(s), s)
        except ConvertError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        self.report({'INFO'}, f"Linked {n} bones.")
        return {'FINISHED'}


class SFMRIGIFY_OT_unlink(_Base):
    bl_idname = "sfm_rigify.unlink"
    bl_label = "Remove Link"
    bl_description = "Remove constraints from the source skeleton and helper bones from the rig"

    def execute(self, context):
        s = context.scene.sfm_rigify
        unlink(s.source, get_rig(s))
        try:
            s.source.hide_set(False)
        except Exception:
            pass
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# UI / properties
# ----------------------------------------------------------------------------

class SFMRIGIFY_OT_use_active(bpy.types.Operator):
    bl_idname = "sfm_rigify.use_active"
    bl_label = "Use Active Armature"
    bl_description = "Take the active armature object as the source"

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'ARMATURE'

    def execute(self, context):
        context.scene.sfm_rigify.source = context.active_object
        return {'FINISHED'}


def _armature_poll(self, obj):
    return obj.type == 'ARMATURE'


class SFMBoneKeep(bpy.types.PropertyGroup):
    # .name = bone name; keep = visible (True) / hidden (False)
    keep: BoolProperty(name="Keep", default=True, update=_bone_keep_update,
                       description="Keep this bone visible (untick to hide it)")


class SFMRIGIFY_OT_eye_fix(bpy.types.Operator):
    bl_idname = "sfm_rigify.eye_fix"
    bl_label = "Eye Fix"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = (
        "Add an 'eyetarget' bone parented to the head bone, put an Empty on it and make "
        "the eyes (eye_0 / eye_1) track that Empty. Run it again to update")

    @classmethod
    def poll(cls, context):
        s = context.scene.sfm_rigify
        return s.source is not None or get_rig(s) is not None

    def execute(self, context):
        s = context.scene.sfm_rigify
        try:
            n, emp = eye_fix(context, s)
        except ConvertError as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        self.report({'INFO'}, f"{n} eye(s) track '{emp.name}' (bone '{EYE_BONE}').")
        return {'FINISHED'}


class SFMRIGIFY_OT_new_eye_shader(bpy.types.Operator):
    bl_idname = "sfm_rigify.new_eye_shader"
    bl_label = "New Eye Shader"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = (
        "Build a tracked SFM-style eye shader. The iris follows eye_0 / eye_1 and "
        "does not slide when the camera moves; the original material is kept")

    def execute(self, context):
        changed, skipped, untracked = make_stable_eye_shaders(context, context.scene.sfm_rigify)
        if not changed:
            if untracked:
                self.report({'WARNING'},
                            "Eye tracking empties were not found. Choose Eye L / Eye R and run Eye Fix first.")
                return {'CANCELLED'}
            if skipped:
                self.report({'WARNING'},
                            "Found eye materials, but no color/iris texture was available; nothing changed.")
            else:
                self.report({'WARNING'},
                            "No eye materials found. Select the model's face/eye mesh or armature first.")
            return {'CANCELLED'}
        message = f"Built tracked eye shader for {changed} material slot(s); original materials were kept."
        if skipped:
            message += f" Skipped {skipped} material(s) without a usable texture."
        if untracked:
            message += f" Skipped {untracked} material slot(s) without an eye empty."
        self.report({'INFO'}, message)
        return {'FINISHED'}


class SFMRIGIFY_OT_eye_fix_remove(bpy.types.Operator):
    bl_idname = "sfm_rigify.eye_fix_remove"
    bl_label = "Remove Eye Fix"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Remove the eyetarget bone, its Empty and the eye tracking constraints"

    @classmethod
    def poll(cls, context):
        s = context.scene.sfm_rigify
        return s.source is not None or get_rig(s) is not None

    def execute(self, context):
        eye_fix_remove(context, context.scene.sfm_rigify)
        return {'FINISHED'}


class SFMRIGIFY_OT_bones_load(bpy.types.Operator):
    bl_idname = "sfm_rigify.bones_load"
    bl_label = "Load Bones"
    bl_description = "List the bones of the chosen armature with their current visibility"

    @classmethod
    def poll(cls, context):
        return _bone_arm(context.scene.sfm_rigify) is not None

    def execute(self, context):
        global _BONE_LOCK
        s = context.scene.sfm_rigify
        arm = _bone_arm(s)
        _BONE_LOCK = True
        try:
            s.bone_list.clear()
            for b in arm.data.bones:
                it = s.bone_list.add()
                it.name = b.name
                it.keep = not b.hide
        finally:
            _BONE_LOCK = False
        s.bone_index = 0
        return {'FINISHED'}


class SFMRIGIFY_OT_bones_set(bpy.types.Operator):
    bl_idname = "sfm_rigify.bones_set"
    bl_label = "Set Bones"
    bl_options = {'REGISTER', 'UNDO'}
    mode: EnumProperty(items=[
        ('ALL', "All", "Keep every bone visible"),
        ('NONE', "None", "Hide every bone"),
        ('INVERT', "Invert", "Swap kept and hidden"),
        ('UNDRIVEN', "Not driven by rig",
         "Keep only the source bones that the Rigify rig does not drive"),
        ('CONTROLS', "Controls only", "Hide DEF- / ORG- / MCH- / helper bones"),
    ])

    @classmethod
    def poll(cls, context):
        s = context.scene.sfm_rigify
        return _bone_arm(s) is not None and len(s.bone_list) > 0

    def execute(self, context):
        global _BONE_LOCK
        s = context.scene.sfm_rigify
        arm = _bone_arm(s)
        _BONE_LOCK = True
        any_kept = False
        try:
            for it in s.bone_list:
                b = arm.data.bones.get(it.name)
                if b is None:
                    continue
                if self.mode == 'ALL':
                    keep = True
                elif self.mode == 'NONE':
                    keep = False
                elif self.mode == 'INVERT':
                    keep = not it.keep
                elif self.mode == 'UNDRIVEN':
                    pb = arm.pose.bones.get(it.name)
                    keep = not (pb and any(c.name.startswith(CON_PREFIX)
                                           for c in pb.constraints))
                else:
                    keep = not it.name.startswith(_NON_CONTROL)
                it.keep = keep
                b.hide = not keep
                any_kept = any_kept or keep
        finally:
            _BONE_LOCK = False
        if any_kept:
            _show_object(arm)
        return {'FINISHED'}


class SFMRIGIFY_UL_bones(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "keep", text="", emboss=False,
                 icon='HIDE_OFF' if item.keep else 'HIDE_ON')
        row.label(text=item.name)


class SFMRigifySettings(bpy.types.PropertyGroup):
    source: PointerProperty(name="Source", type=bpy.types.Object,
                            poll=_armature_poll,
                            description="Imported Source/SFM armature (the one the mesh is skinned to)")
    metarig: PointerProperty(name="Metarig", type=bpy.types.Object, poll=_armature_poll)
    rig: PointerProperty(name="Rig", type=bpy.types.Object, poll=_armature_poll)
    preset: EnumProperty(
        name="Skeleton",
        items=[('AUTO', "Auto-detect", ""),
               ('VALVE', "ValveBiped (HL2 / SFM)", "ValveBiped.Bip01_*"),
               ('TF2', "bip_ (TF2 / L4D)", "bip_pelvis, bip_upperArm_L ...")],
        default='AUTO')
    bend: FloatProperty(
        name="Limb Pre-bend", default=0.02, min=0.0, max=0.2,
        description="Minimum elbow/knee offset (fraction of limb length) so Rigify "
                    "gets a bend direction for IK. Set 0 if your rig is already bent")
    ik_default: BoolProperty(name="IK by default", default=True,
                             description="Set the arm/leg IK-FK sliders to IK")
    hide_source: BoolProperty(name="Hide source armature", default=True,
                              description="Hide the original skeleton (the mesh keeps deforming)")
    head_dir: EnumProperty(
        name="Head bone",
        items=[('FORWARD', "Forward", "Head bone points forward (like the Source head bone)"),
               ('UP', "Up", "Head bone points up (Rigify default)")],
        default='FORWARD',
        description="Direction of the Rigify head bone")
    auto_eye_fix: BoolProperty(
        name="Auto Eye Fix", default=False,
        description="Run Eye Fix automatically after importing / converting")
    eye_left: PointerProperty(
        name="Eye L", type=bpy.types.Object,
        description="Eye object (empty). Leave empty to auto-detect eye_0 / eye_1")
    eye_right: PointerProperty(
        name="Eye R", type=bpy.types.Object,
        description="Eye object (empty). Leave empty to auto-detect eye_0 / eye_1")
    eye_distance: FloatProperty(
        name="Distance", default=0.0, min=0.0, unit='LENGTH',
        description="How far in front of the eyes the target is (0 = automatic)")
    bone_target: EnumProperty(
        name="Armature",
        items=[('SOURCE', "Source", "Original Source skeleton"),
               ('RIG', "Rig", "Generated Rigify rig")],
        default='SOURCE',
        update=lambda self, ctx: self.bone_list.clear())
    bone_list: CollectionProperty(type=SFMBoneKeep)
    bone_index: IntProperty(default=0)


class SFMRIGIFY_PT_panel(bpy.types.Panel):
    bl_label = "Rigify Existing Model"
    bl_idname = "SFMRIGIFY_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SFM Import"

    def draw(self, context):
        s = context.scene.sfm_rigify
        col = self.layout.column(align=True)
        row = col.row(align=True)
        row.prop(s, "source")
        row.operator("sfm_rigify.use_active", text="", icon="EYEDROPPER")
        col.prop(s, "preset")
        col = self.layout.column(align=True)
        col.prop(s, "bend")
        col.prop(s, "ik_default")
        col.prop(s, "hide_source")
        col.prop(s, "head_dir")
        col.prop(s, "auto_eye_fix")

        self.layout.separator()
        row = self.layout.row()
        row.scale_y = 1.6
        row.operator("sfm_rigify.convert", icon='ARMATURE_DATA')

        box = self.layout.box()
        box.label(text="Step by step")
        box.operator("sfm_rigify.build_metarig")
        box.prop(s, "metarig", text="")
        box.operator("sfm_rigify.generate_link")
        box.prop(s, "rig", text="")
        row = box.row(align=True)
        row.operator("sfm_rigify.relink")
        row.operator("sfm_rigify.unlink")

        # --- Eye Fix ---
        box = self.layout.box()
        box.label(text="Eye Fix", icon='HIDE_OFF')
        col = box.column(align=True)
        col.prop(s, "eye_left")
        col.prop(s, "eye_right")
        col.prop(s, "eye_distance")
        row = box.row(align=True)
        row.scale_y = 1.3
        row.operator("sfm_rigify.eye_fix", icon='CON_TRACKTO')
        row.operator("sfm_rigify.new_eye_shader", text="New Shader", icon='MATERIAL')
        box.operator("sfm_rigify.eye_fix_remove", text="Remove Eye Fix", icon='X')

        # --- keep / hide bones ---
        box = self.layout.box()
        box.label(text="Bones: keep / hide", icon='BONE_DATA')
        box.row().prop(s, "bone_target", expand=True)
        box.operator("sfm_rigify.bones_load", icon='FILE_REFRESH')
        if len(s.bone_list):
            box.template_list("SFMRIGIFY_UL_bones", "", s, "bone_list", s, "bone_index", rows=8)
            row = box.row(align=True)
            for mode, label in (('ALL', "All"), ('NONE', "None"), ('INVERT', "Invert")):
                row.operator("sfm_rigify.bones_set", text=label).mode = mode
            row = box.row(align=True)
            if s.bone_target == 'SOURCE':
                row.operator("sfm_rigify.bones_set", text="Not driven by rig").mode = 'UNDRIVEN'
            else:
                row.operator("sfm_rigify.bones_set", text="Controls only").mode = 'CONTROLS'


# ============================================================================
# Advanced Face Poser PRO
# ============================================================================

# ─────────────────────────────
# GROUPS
# ─────────────────────────────
GROUPS = {
    "Eyes": ["eye", "blink", "lid", "squint", "wink", "close"],
    "Brows": ["brow"],
    "Cheeks": ["cheek", "puff", "dimple"],
    "Nose": ["nose", "nostril"],
    "Mouth": ["mouth", "jaw", "chin", "smile", "frown", "open"],
    "Lips": ["lip", "pucker", "funnel", "tighten", "press", "suck", "bite"],
    "Tongue": ["tongue"],
}

SOLO_GROUP_ITEMS = [("ALL", "All", "Show all groups")] + [
    (g, g, f"Show only {g}") for g in list(GROUPS.keys()) + ["Other"]
]

# ─────────────────────────────
# NAME MAP
# ─────────────────────────────
NAME_MAP = {
    "smile": "Smile",
    "frown": "Frown",
    "blink": "Blink",
    "jawopen": "Jaw_Open",
    "mouthopen": "Mouth_Open",
    "browup": "Brow_Raise",
    "browdown": "Brow_Lower",
    "cheekraise": "Cheek_Raise",
    "lipspucker": "Lip_Pucker",
}

# Names used by ARKit, common FACS rigs, and several popular face-rig exports.
# The keys intentionally contain only letters and numbers: _control_token() uses
# the same representation, so CamelCase, spaces, dots, and underscores all match.
CONTROL_ALIASES = {
    # Brows / cheeks
    "browdown": "Brow_Lower",
    "browlower": "Brow_Lower",
    "browup": "Brow_Raise",
    "browraise": "Brow_Raise",
    "browinnerup": "Inner_Brow_Raise",
    "innerbrowraise": "Inner_Brow_Raise",
    "browouterup": "Outer_Brow_Raise",
    "outerbrowraise": "Outer_Brow_Raise",
    "cheekraise": "Cheek_Raise",
    "cheeksquint": "Cheek_Raise",
    "cheekpuff": "Cheek_Puff",
    "mouthdimple": "Dimpler",
    "dimpler": "Dimpler",
    # Eyes
    "eyeblink": "Blink",
    "blink": "Blink",
    "eyeclose": "Eye_Close",
    "eyeclosed": "Eye_Close",
    "eyewide": "Eye_Wide",
    "eyesquint": "Lid_Tighten",
    "eyelookdown": "Eye_Look_Down",
    "eyelookup": "Eye_Look_Up",
    "eyelookin": "Eye_Look_In",
    "eyelookout": "Eye_Look_Out",
    # Jaw / mouth / lips
    "jawopen": "Jaw_Open",
    "mouthopen": "Mouth_Open",
    "jawforward": "Jaw_Forward",
    "mouthclose": "Mouth_Close",
    "mouthsmile": "Smile",
    "smile": "Smile",
    "lipcornerpuller": "Smile",
    "mouthfrown": "Frown",
    "frown": "Frown",
    "lipcornerdepressor": "Frown",
    "mouthfunnel": "Lip_Funnel",
    "lipfunnel": "Lip_Funnel",
    "mouthpucker": "Lip_Pucker",
    "lipspucker": "Lip_Pucker",
    "mouthpress": "Lip_Press",
    "lippress": "Lip_Press",
    "mouthstretch": "Lip_Stretch",
    "lipstretch": "Lip_Stretch",
    "mouthlowerdown": "LowerLip_Depress",
    "lowerlipdepress": "LowerLip_Depress",
    "mouthupperup": "UpperLip_Raise",
    "upperlipraise": "UpperLip_Raise",
    "mouthrolllower": "LowerLip_Roll",
    "mouthrollupper": "UpperLip_Roll",
    "mouthshruglower": "LowerLip_Shrug",
    "mouthshrugupper": "UpperLip_Shrug",
    "liptighten": "Lip_Tighten",
    "lipsuck": "Lip_Suck",
    "lipbite": "Lip_Bite",
    "nosesneer": "Nose_Wrinkle",
    "nosewrinkle": "Nose_Wrinkle",
    "tongueout": "Tongue_Out",
}

# ─────────────────────────────
# AU RENAME (FACS)
# ─────────────────────────────
AU_BASE = {
    "1": "Inner_Brow_Raise",
    "2": "Outer_Brow_Raise",
    "4": "Brow_Lower",
    "5": "Upper_Lid_Raise",
    "6": "Cheek_Raise",
    "7": "Lid_Tighten",
    "9": "Nose_Wrinkle",
    "10": "UpperLip_Raise",
    "12": "Smile",
    "14": "Dimpler",
    "15": "Lip_Corner_Down",
    "16": "LowerLip_Depress",
    "17": "Chin_Raise",
    "18": "Lip_Pucker",
    "20": "Lip_Stretch",
    "22": "Lip_Funnel",
    "23": "Lip_Tighten",
    "24": "Lip_Press",
    "25": "Mouth_Open",
    "26": "Jaw_Open",
    "27": "Mouth_Stretch",
    "28": "Lip_Suck",
    "32": "Lip_Bite",
    "43": "Eye_Close",
    "45": "Blink",
}


# ─────────────────────────────
# HELPERS
# ─────────────────────────────
def ensure_object_mode(context):
    if context.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")


def _sourceio_flex_controllers(obj):
    """Return SourceIO's native flex-controller collection, if this mesh has one."""
    if not obj or obj.type != "MESH":
        return None
    controllers = getattr(obj.data, "flex_controllers", None)
    try:
        return controllers if controllers is not None and len(controllers) else None
    except Exception:
        return None


def _has_sourceio_flexes(obj):
    return _sourceio_flex_controllers(obj) is not None


def get_mesh(context):
    """Active mesh usable by Face Poser: Blender keys or SourceIO HWM flexes."""
    obj = context.object
    if not obj or obj.type != "MESH":
        return None
    if obj.data.shape_keys or _has_sourceio_flexes(obj):
        return obj
    return None


def _faceposer_prop_path(prop):
    """Data path for our generated, ASCII-only object custom properties."""
    return f'["{prop}"]'


def _is_faceposer_prop(prop):
    return isinstance(prop, str) and (
        prop.startswith("SK_") or prop.startswith("SKX_") or prop.startswith("FP_HWM_"))


def _is_shape_key_prop(prop):
    return isinstance(prop, str) and (prop.startswith("SK_") or prop.startswith("SKX_"))


def get_group(name):
    nl = name.lower()
    for g, words in GROUPS.items():
        if any(w in nl for w in words):
            return g
    return "Other"


_SIDE_LETTER_RE = re.compile(r"^(?P<core>.+?)[_.\-\s]+(?P<side>[LR])$", re.IGNORECASE)
_SIDE_WORD_RE = re.compile(r"^(?P<core>.+?)[_.\-\s]*(?P<side>left|right)$", re.IGNORECASE)
_SIDE_PREFIX_LETTER_RE = re.compile(r"^(?P<side>[LR])[_.\-\s]+(?P<core>.+)$", re.IGNORECASE)
_SIDE_PREFIX_WORD_RE = re.compile(r"^(?P<side>left|right)[_.\-\s]*(?P<core>.+)$", re.IGNORECASE)


def _control_token(name: str) -> str:
    """Case- and separator-independent token used for known control aliases."""
    return re.sub(r"[^a-z0-9]+", "", name.lower())


def _format_control_name(name: str) -> str:
    """Turn an unknown sided name into a stable, readable pair base."""
    spaced = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", name)
    words = re.findall(r"[A-Za-z]+|\d+", spaced)
    if not words:
        return name
    return "_".join(w if w.isupper() else w[:1].upper() + w[1:] for w in words)


def split_side(name):
    """
    'eyeBlinkLeft' -> ('eyeBlink', 'L'); 'Smile.R' -> ('Smile', 'R');
    'Left_Brow' -> ('Brow', 'L'); 'Smile' -> ('Smile', None).
    Detects an explicit side prefix or suffix only, so 'Upper_Lid_Raise' /
    'Brow_Raise' are NOT sided.
    """
    n = re.sub(r"\.\d+$", "", name)

    # ARKit's mouthLeft/mouthRight and jawLeft/jawRight are directional,
    # centered controls -- they are not the left/right halves of one control.
    # Do not turn them into an accidental Trifecta pair.
    if not re.search(r"[_.\-\s]", n) and _control_token(n) in {"mouthleft", "mouthright", "jawleft", "jawright"}:
        return n, None

    for rx in (_SIDE_LETTER_RE, _SIDE_WORD_RE):
        m = rx.match(n)
        if m:
            return m.group("core"), m.group("side")[0].upper()
    for rx in (_SIDE_PREFIX_LETTER_RE, _SIDE_PREFIX_WORD_RE):
        m = rx.match(n)
        if m:
            return m.group("core"), m.group("side")[0].upper()
    return n, None


def get_side(name):
    return split_side(name)[1] or "C"


def _vg_weight(vg, idx):
    if not vg:
        return 0.0
    try:
        return vg.weight(idx)
    except RuntimeError:
        return 0.0


def _symmetry_center_x(ref_key):
    """Best-effort local symmetry plane; supports meshes not centred on X=0."""
    try:
        xs = [point.co.x for point in ref_key.data]
        return (min(xs) + max(xs)) * 0.5 if xs else 0.0
    except Exception:
        return 0.0


def _vertex_side(idx, ref_co, vg_L, vg_R, eps=1e-6, center_x=0.0):
    wL = _vg_weight(vg_L, idx)
    wR = _vg_weight(vg_R, idx)

    if wL > 0.0 or wR > 0.0:
        if wL > 0.0 and wR <= 0.0:
            return "L"
        if wR > 0.0 and wL <= 0.0:
            return "R"
        if abs(wL - wR) > 1e-6:
            return "L" if wL > wR else "R"

    if ref_co.x < center_x - eps:
        return "L"
    if ref_co.x > center_x + eps:
        return "R"
    return "C"


def _smoothstep01(value):
    """Cubic easing used around the face centre, with no hard split seam."""
    value = max(0.0, min(1.0, value))
    return value * value * (3.0 - 2.0 * value)


def _split_side_weights(idx, ref_co, vg_L, vg_R, center_width, eps=1e-6, center_x=0.0):
    """
    Return (left, right) influence for a centre shape key.

    A weighted Left/Right vertex group is honoured when present.  Otherwise
    the transition is eased over a configurable strip around X=0.  This is
    deliberately different from cutting the head into two hard halves: with
    both sides at 1.0 the original flex is reconstructed exactly, while a
    one-sided pose falls off naturally over the nose/philtrum area.
    """
    w_left = _vg_weight(vg_L, idx)
    w_right = _vg_weight(vg_R, idx)
    total = w_left + w_right
    if total > eps:
        return w_left / total, w_right / total

    width = max(float(center_width), eps)
    # Source/Blender convention in this addon: negative local X is L.
    right = _smoothstep01((ref_co.x - center_x + width) / (2.0 * width))
    return 1.0 - right, right


def _canonical_name(name: str) -> str:
    # Blender duplicates often end with ".001" etc. Treat them as the same control.
    return re.sub(r"\.\d+$", "", name)


_IDPROP_NAME_LIMIT = 63


def _shape_key_prop_id(name):
    """Return a stable Blender IDProperty key (Blender limits names to 63 chars)."""
    name = _canonical_name(str(name))
    legacy = f"SK_{name}"
    if len(legacy.encode("utf-8")) <= _IDPROP_NAME_LIMIT:
        return legacy
    digest = hashlib.sha1(name.encode("utf-8")).hexdigest()[:20]
    return f"SKX_{digest}"


def _shape_key_prop(obj, key_or_name):
    """Resolve a Face Poser property name without mutating Blender data.

    This helper is also used while drawing the UI, where Blender forbids
    writing to ID datablocks. Keys are deterministic, so a missing legacy
    mapping can safely fall back to the short hashed property identifier.
    """
    name = key_or_name.name if hasattr(key_or_name, "name") else str(key_or_name)
    mapping = obj.get("_faceposer_key_prop_map", {}) if obj else {}
    try:
        mapping = dict(mapping.items())
    except Exception:
        mapping = {}
    return mapping.get(name) or _shape_key_prop_id(name)


def _shape_key_for_prop(obj, prop):
    shape_keys = getattr(getattr(obj, "data", None), "shape_keys", None)
    if not shape_keys:
        return None
    for key in shape_keys.key_blocks:
        if _shape_key_prop(obj, key.name) == prop:
            return key
    return None


def _control_label(obj, prop):
    key = _shape_key_for_prop(obj, prop)
    return _canonical_name(key.name) if key else (prop[3:] if prop.startswith("SK_") else prop)


def _is_basis_key(shape_keys, key) -> bool:
    try:
        ref = getattr(shape_keys, "reference_key", None)
        if ref is not None and key == ref:
            return True
        blocks = getattr(shape_keys, "key_blocks", None)
        if blocks and key == blocks[0]:
            return True
    except Exception:
        pass
    return False


def _base_from_lr(name):
    name = _canonical_name(name)
    m = re.match(r"^(.*)_[LR]$", name, re.IGNORECASE)
    return m.group(1) if m else None


def refresh_pair_sliders(obj):
    """
    Build/refresh a list of "Both" sliders that drive SK_<base>_L and SK_<base>_R.
    Stored as a CollectionProperty on the object so it can have an update callback.
    """
    if not hasattr(obj, "faceposer_pair_sliders"):
        return

    lr_presence = {}
    if not obj.data.shape_keys:
        return
    for key in obj.data.shape_keys.key_blocks:
        if _is_basis_key(obj.data.shape_keys, key):
            continue
        n = _canonical_name(key.name)
        base = _base_from_lr(n)
        if not base:
            continue
        lr_presence.setdefault(base, set()).add(n[-1].upper())  # 'L' or 'R'

    bases = sorted([b for b, sides in lr_presence.items() if "L" in sides and "R" in sides])

    existing_names = {item.name for item in obj.faceposer_pair_sliders}

    # Remove stale items
    for i in range(len(obj.faceposer_pair_sliders) - 1, -1, -1):
        if obj.faceposer_pair_sliders[i].name not in bases:
            obj.faceposer_pair_sliders.remove(i)

    # Add missing and update values
    name_to_item = {item.name: item for item in obj.faceposer_pair_sliders}
    for base in bases:
        if base not in existing_names:
            item = obj.faceposer_pair_sliders.add()
            item.name = base
            name_to_item[base] = item

        item = name_to_item[base]
        pL = _shape_key_prop(obj, f"{base}_L")
        pR = _shape_key_prop(obj, f"{base}_R")
        if pL in obj and pR in obj:
            try:
                item.syncing = True
                item.value = (float(obj[pL]) + float(obj[pR])) / 2.0
            except Exception:
                item.syncing = True
                item.value = 0.0
            finally:
                item.syncing = False


def cleanup_faceposer_properties(obj):
    """
    Remove stale SK_ custom properties that no longer correspond to current shape keys.
    Also de-duplicates by treating names with Blender suffixes (e.g. .001) as the same control.
    """
    if not obj or not obj.data or not obj.data.shape_keys:
        return 0

    expected = set()
    shape_keys = obj.data.shape_keys
    for key in shape_keys.key_blocks:
        if _is_basis_key(shape_keys, key):
            continue
        expected.add(_shape_key_prop(obj, key.name))

    removed = 0
    for p in list(obj.keys()):
        if not isinstance(p, str) or not (p.startswith("SK_") or p.startswith("SKX_")):
            continue
        if p not in expected:
            try:
                del obj[p]
                removed += 1
            except Exception:
                pass

    return removed


def cleanup_favorites(scene, obj):
    if not scene or not hasattr(scene, "faceposer_favorites") or not obj:
        return 0

    existing_props = set(k for k in obj.keys() if _is_shape_key_prop(k))
    paired_bases = set()
    if hasattr(obj, "faceposer_pair_sliders"):
        paired_bases = {it.name for it in obj.faceposer_pair_sliders}

    removed = 0
    for i in range(len(scene.faceposer_favorites) - 1, -1, -1):
        item = scene.faceposer_favorites[i]
        key = item.key
        if key.startswith("PAIR:"):
            base = key[5:]
            if base not in paired_bases:
                scene.faceposer_favorites.remove(i)
                removed += 1
        elif key.startswith("PROP:"):
            prop = key[5:]
            if prop not in existing_props:
                scene.faceposer_favorites.remove(i)
                removed += 1
        else:
            scene.faceposer_favorites.remove(i)
            removed += 1

    return removed


# ─────────────────────────────
# RENAME
# ─────────────────────────────
_AU_TOKEN_RE = re.compile(r"^(au|a)?(\d+)(l|r|left|right)?$", re.IGNORECASE)
_KEY_DRIVER_RE = re.compile(r'^key_blocks\["(.+)"\]\.value$')
_NAME_MAP_KEYS = sorted(NAME_MAP, key=len, reverse=True)


def _iter_fcurves(anim_data):
    """F-curves of the active action (works for legacy and layered/slotted actions)."""
    act = getattr(anim_data, "action", None) if anim_data else None
    if not act:
        return
    legacy = getattr(act, "fcurves", None)
    if legacy is not None:
        yield from legacy
        return
    slot = getattr(anim_data, "action_slot", None)
    if slot is None:
        return
    for layer in getattr(act, "layers", []):
        for strip in layer.strips:
            if getattr(strip, "type", "") != "KEYFRAME":
                continue
            try:
                cb = strip.channelbag(slot)
            except Exception:
                cb = None
            if cb:
                yield from cb.fcurves


def _retarget_fcurves(obj, old_path, new_path):
    fcs = list(_iter_fcurves(obj.animation_data))
    if any(fc.data_path == new_path for fc in fcs):
        return
    for fc in fcs:
        if fc.data_path == old_path:
            fc.data_path = new_path


def _retarget_key_driver(shape_keys, old_name, new_name, old_path, new_path):
    ad = shape_keys.animation_data
    if not ad:
        return
    for fc in ad.drivers:
        m = _KEY_DRIVER_RE.match(fc.data_path)
        if not m or m.group(1) not in (old_name, new_name):
            continue
        if m.group(1) == old_name:
            fc.data_path = f'key_blocks["{new_name}"].value'
        for v in fc.driver.variables:
            for t in v.targets:
                if t.data_path == old_path:
                    t.data_path = new_path


def _migrate_favorites(old_prop, new_prop, old_name="", new_name=""):
    favs = getattr(bpy.context.scene, "faceposer_favorites", None)
    if favs is None:
        return
    old_base = _base_from_lr(old_name or old_prop[3:])
    new_base = _base_from_lr(new_name or new_prop[3:])
    for item in favs:
        if item.key == f"PROP:{old_prop}":
            item.key = f"PROP:{new_prop}"
        elif old_base and new_base and item.key == f"PAIR:{old_base}":
            item.key = f"PAIR:{new_base}"


def _rename_key(obj, key, new_name) -> bool:
    """
    Rename a shape key and carry everything attached to the old name with it:
    SK_ custom property (value), its keyframes, the key's own driver and favorites.
    Returns False (and changes nothing) if the name is already taken.
    """
    shape_keys = obj.data.shape_keys
    blocks = shape_keys.key_blocks
    old_name = key.name
    old_canon = _canonical_name(old_name)
    new_canon = _canonical_name(new_name)

    for other in blocks:
        if other is not key and _canonical_name(other.name) == new_canon:
            return False

    key.name = new_name
    new_name = key.name

    if old_canon != new_canon:
        old_prop = _shape_key_prop(obj, old_name)
        new_prop = _shape_key_prop_id(new_name)
        old_path = f'["{old_prop}"]'
        new_path = f'["{new_prop}"]'

        if old_prop in obj and new_prop not in obj:
            try:
                obj[new_prop] = float(obj[old_prop])
                obj.id_properties_ui(new_prop).update(min=0, max=1)
            except Exception:
                pass

        _retarget_key_driver(shape_keys, old_name, new_name, old_path, new_path)

        shared = any(o is not key and _canonical_name(o.name) == old_canon for o in blocks)
        if not shared and old_prop in obj:
            _retarget_fcurves(obj, old_path, new_path)
            try:
                del obj[old_prop]
            except Exception:
                pass

        _migrate_favorites(old_prop, new_prop, old_canon, new_canon)

    return True


def _plan_au_name(orig):
    """'AU12L', 'AU12_L', 'AU 12 R', 'au12_left', '12 R' -> 'Smile_L' / 'Smile_R'. None if not an AU name."""
    # An outer suffix is authoritative. It appears when an earlier add-on
    # version split an existing AU12R into AU12R_L / AU12R_R.
    core_name, outer_side = split_side(_canonical_name(orig))
    tokens = [t for t in re.split(r"[^0-9A-Za-z]+", core_name) if t]
    if not tokens:
        return None

    # "AU 12" -> "AU12"
    merged = []
    i = 0
    while i < len(tokens):
        t = tokens[i]
        if (
            t.lower() in ("au", "a")
            and i + 1 < len(tokens)
            and re.match(r"^\d+(l|r|left|right)?$", tokens[i + 1], re.IGNORECASE)
        ):
            merged.append(t + tokens[i + 1])
            i += 2
        else:
            merged.append(t)
            i += 1
    tokens = merged

    parts = []
    parsed_sides = []
    consumed = 0
    prefixed = False
    i = 0
    while i < len(tokens):
        m = _AU_TOKEN_RE.match(tokens[i])
        base = AU_BASE.get(str(int(m.group(2)))) if m else None
        if not base:
            i += 1
            continue

        side = (m.group(3) or "")[:1].upper()
        used = 1
        if not side and i + 1 < len(tokens) and tokens[i + 1].lower() in ("l", "r", "left", "right"):
            side = tokens[i + 1][0].upper()
            used = 2

        prefixed = prefixed or bool(m.group(1))
        parts.append(base)
        parsed_sides.append(side or None)
        consumed += used
        i += used

    if not parts:
        return None
    # A bare number ("12") is only an AU if nothing else is in the name.
    if not prefixed and consumed < len(tokens):
        return None
    # Multiple AUs can be packed into one Source/TF2 key. If all of their
    # individual suffixes agree, put a single suffix on the combined base so
    # its left and right variants can still form one Trifecta pair.
    sides = {s for s in parsed_sides if s}
    common_side = outer_side or (next(iter(sides)) if len(sides) == 1 else None)
    if common_side:
        return "_".join(parts) + f"_{common_side}"

    return "_".join(base + (f"_{side}" if side else "") for base, side in zip(parts, parsed_sides))


def _plan_map_name(orig):
    """Normalize common rig names and every clear L/R suffix into one pair convention."""
    core, side = split_side(orig)
    token = _control_token(core)

    base = CONTROL_ALIASES.get(token)
    if not base:
        # Keep compatibility with the original short-name map and with control
        # names that include a prefix/suffix from an exporter.
        for k in _NAME_MAP_KEYS:
            if k in token:
                base = NAME_MAP[k]
                break

    # A recognized side is enough to make a stable Trifecta pair even when its
    # expression name is custom. This is the important fallback for names such
    # as "Face.Cheek_Puff.Left" and "R_BespokeExpression".
    if not base and side:
        base = _format_control_name(core)

    return base + (f"_{side}" if base and side else "") if base else None


def rename_shape_keys_au(obj) -> int:
    """
    Rename shape keys like 'AU12L', 'AU12_L', 'AU 12 R' into human FACS names.
    Returns the number of keys renamed.
    """
    if not obj or not obj.data or not obj.data.shape_keys:
        return 0

    shape_keys = obj.data.shape_keys
    renamed = 0
    for key in list(shape_keys.key_blocks):
        if _is_basis_key(shape_keys, key):
            continue
        new_name = _plan_au_name(key.name)
        if not new_name or _canonical_name(new_name) == _canonical_name(key.name):
            continue
        if _rename_key(obj, key, new_name):
            renamed += 1
    return renamed


def smart_rename(obj):
    """AU names first, then NAME_MAP. Returns (renamed, skipped_because_name_taken)."""
    shape_keys = obj.data.shape_keys
    renamed = skipped = 0

    for key in list(shape_keys.key_blocks):
        if _is_basis_key(shape_keys, key):
            continue

        orig = key.name
        new_name = _plan_au_name(orig) or _plan_map_name(orig)
        if not new_name or _canonical_name(new_name) == _canonical_name(orig):
            continue

        if _rename_key(obj, key, new_name):
            renamed += 1
        else:
            skipped += 1

    return renamed, skipped


# ─────────────────────────────
# AUTO SPLIT
# ─────────────────────────────
class FACEPOSER_OT_rename_au(bpy.types.Operator):
    bl_idname = "faceposer.rename_au"
    bl_label = "Smart Rename → FACS"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ensure_object_mode(context)
        obj = get_mesh(context)
        if not obj:
            self.report({"WARNING"}, "Select a mesh with shape keys")
            return {"CANCELLED"}

        renamed, skipped = smart_rename(obj)
        refresh_pair_sliders(obj)
        if renamed or skipped:
            details = [f"renamed {renamed}"]
            if skipped:
                details.append(f"skipped {skipped} duplicate name(s)")
            self.report({"INFO"}, "Smart Rename: " + ", ".join(details))
        else:
            self.report({"INFO"}, "No recognizable shape-key names found")
        return {"FINISHED"}


class FACEPOSER_OT_auto_split(bpy.types.Operator):
    bl_idname = "faceposer.auto_split"
    bl_label = "Split Center Keys L/R (Smooth)"
    bl_options = {"REGISTER", "UNDO"}

    falloff: FloatProperty(
        name="Centre Falloff",
        default=0.12,
        min=0.001,
        max=0.5,
        description="Width of the smooth L/R blend around the face centre, as a fraction of head width",
    )

    def execute(self, context):
        ensure_object_mode(context)
        obj = get_mesh(context)
        if not obj:
            self.report({"WARNING"}, "Select a mesh with shape keys")
            return {"CANCELLED"}

        mesh = obj.data
        keys = mesh.shape_keys.key_blocks
        shape_keys = mesh.shape_keys
        basis = shape_keys.reference_key if shape_keys else (keys[0] if keys else None)
        if not basis:
            self.report({"WARNING"}, "No Basis shape key found")
            return {"CANCELLED"}

        vg_L = obj.vertex_groups.get("Left")
        vg_R = obj.vertex_groups.get("Right")

        # Split center keys only. AU12R, Smile.Right, and other side-labelled
        # keys must never become AU12R_L / AU12R_R -- those are repaired or
        # mirrored by the dedicated operator below.
        to_split = []
        for key in keys:
            if _is_basis_key(shape_keys, key):
                continue
            if get_side(_canonical_name(key.name)) in {"L", "R"}:
                continue
            to_split.append(key)

        if not to_split:
            self.report({"INFO"}, "No center shape keys to split")
            return {"CANCELLED"}

        vertex_count = len(mesh.vertices)
        if not vertex_count:
            self.report({"WARNING"}, "Mesh has no vertices")
            return {"CANCELLED"}
        center_x = _symmetry_center_x(basis)
        half_width = max(abs(point.co.x - center_x) for point in basis.data)
        center_width = max(half_width * self.falloff, 1e-6)

        for key in to_split:
            name_L = f"{key.name}_L"
            name_R = f"{key.name}_R"

            if name_L in keys or name_R in keys:
                continue

            ref_key = key.relative_key if key.relative_key else basis

            kL = obj.shape_key_add(name=name_L, from_mix=False)
            kR = obj.shape_key_add(name=name_R, from_mix=False)

            # Keep the same relative base as the original key (important for non-Basis relative keys).
            try:
                kL.relative_key = ref_key
                kR.relative_key = ref_key
            except Exception:
                pass

            for nk in (kL, kR):
                nk.value = 0.0
                nk.slider_min = key.slider_min
                nk.slider_max = key.slider_max
                try:
                    nk.interpolation = key.interpolation
                except Exception:
                    pass

            # Split deltas with a smooth centre transition.  The two new keys
            # add up to the source key at full strength, so this does not
            # weaken the expression when both sides are enabled.
            for i in range(vertex_count):
                ref_co = ref_key.data[i].co
                orig_co = key.data[i].co
                left_weight, right_weight = _split_side_weights(
                    i, ref_co, vg_L, vg_R, center_width, center_x=center_x)
                delta = orig_co - ref_co
                kL.data[i].co = ref_co + delta * left_weight
                kR.data[i].co = ref_co + delta * right_weight

            # Remove the original key to avoid duplicate controls (keep only _L/_R).
            # Skip removal if something else uses it as a relative_key.
            used_as_relative = False
            try:
                shape_keys2 = obj.data.shape_keys
                for other in shape_keys2.key_blocks:
                    if other is key or _is_basis_key(shape_keys2, other):
                        continue
                    if getattr(other, "relative_key", None) is key:
                        used_as_relative = True
                        break
            except Exception:
                used_as_relative = True

            if not used_as_relative:
                try:
                    obj.shape_key_remove(key)
                except Exception:
                    pass

        refresh_pair_sliders(obj)
        self.report({"INFO"}, "Center keys split with a smooth L/R falloff. Run Connect Shape Keys.")
        return {"FINISHED"}


def _copy_shape_key_settings(source, target, relative_key):
    """Copy the non-geometry settings needed by a generated mirror key."""
    try:
        target.relative_key = relative_key
    except Exception:
        pass
    target.value = 0.0
    target.slider_min = source.slider_min
    target.slider_max = source.slider_max
    try:
        target.interpolation = source.interpolation
    except Exception:
        pass


def _key_has_side_effect(key, ref_key, wanted_side, vg_L, vg_R, eps=1e-6, center_x=0.0):
    """True when a key really moves vertices on its named half of the face."""
    eps_sq = eps * eps
    for i, point in enumerate(key.data):
        if _vertex_side(i, ref_key.data[i].co, vg_L, vg_R, center_x=center_x) != wanted_side:
            continue
        ref_co = ref_key.data[i].co
        dx = point.co.x - ref_co.x
        dy = point.co.y - ref_co.y
        dz = point.co.z - ref_co.z
        if dx * dx + dy * dy + dz * dz > eps_sq:
            return True
    return False


def _mirror_shape_key_geometry(obj, source, target, basis):
    """Copy a shape key to the opposite half by mirroring deltas across X=0."""
    ref_key = source.relative_key if source.relative_key else basis
    center_x = _symmetry_center_x(ref_key)
    count = len(obj.data.vertices)
    if count == 0:
        return 0, 0

    # Nearest lookup on the reference shape works with meshes whose vertex
    # indices are not arranged symmetrically, which is common in SMD imports.
    tree = KDTree(count)
    min_x = min_y = min_z = float("inf")
    max_x = max_y = max_z = float("-inf")
    for i, point in enumerate(ref_key.data):
        co = point.co
        tree.insert(co, i)
        min_x, min_y, min_z = min(min_x, co.x), min(min_y, co.y), min(min_z, co.z)
        max_x, max_y, max_z = max(max_x, co.x), max(max_y, co.y), max(max_z, co.z)
    tree.balance()

    diagonal = ((max_x - min_x) ** 2 + (max_y - min_y) ** 2 + (max_z - min_z) ** 2) ** 0.5
    tolerance = max(1e-5, diagonal * 1e-4)
    matched = 0

    for i, target_point in enumerate(target.data):
        ref_co = ref_key.data[i].co
        hit = tree.find((2.0 * center_x - ref_co.x, ref_co.y, ref_co.z))
        if not hit or hit[2] > tolerance:
            target_point.co = ref_co
            continue

        source_index = hit[1]
        source_co = source.data[source_index].co
        source_ref = ref_key.data[source_index].co
        target_point.co = (
            ref_co.x - (source_co.x - source_ref.x),
            ref_co.y + (source_co.y - source_ref.y),
            ref_co.z + (source_co.z - source_ref.z),
        )
        matched += 1

    return matched, count


class FACEPOSER_OT_create_missing_mirror_sides(bpy.types.Operator):
    bl_idname = "faceposer.create_missing_mirror_sides"
    bl_label = "Create Missing Mirrored L/R"
    bl_description = "Create or repair an empty left/right shape key by mirroring its existing opposite side"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ensure_object_mode(context)
        obj = get_mesh(context)
        if not obj:
            self.report({"WARNING"}, "Select a mesh with shape keys")
            return {"CANCELLED"}

        # First repair names such as AU12R_L left behind by the earlier split.
        renamed, skipped = smart_rename(obj)
        shape_keys = obj.data.shape_keys
        basis = shape_keys.reference_key
        center_x = _symmetry_center_x(basis)
        vg_L = obj.vertex_groups.get("Left")
        vg_R = obj.vertex_groups.get("Right")

        pairs = {}
        for key in list(shape_keys.key_blocks):
            if _is_basis_key(shape_keys, key):
                continue
            name = _canonical_name(key.name)
            base = _base_from_lr(name)
            if base:
                pairs.setdefault(base, {})[name[-1].upper()] = key

        created = repaired = matched = total = 0
        for base, sides in pairs.items():
            left = sides.get("L")
            right = sides.get("R")

            # Prefer R -> L when the source rig supplies right-side controls,
            # as in the TF2/SMD face rigs shown in this project.
            if right and (not left or not _key_has_side_effect(left, basis, "L", vg_L, vg_R, center_x=center_x)):
                if not left:
                    left = obj.shape_key_add(name=f"{base}_L", from_mix=False)
                    _copy_shape_key_settings(right, left, right.relative_key if right.relative_key else basis)
                    created += 1
                else:
                    repaired += 1
                got, count = _mirror_shape_key_geometry(obj, right, left, basis)
                matched += got
                total += count
            elif left and (not right or not _key_has_side_effect(right, basis, "R", vg_L, vg_R, center_x=center_x)):
                if not right:
                    right = obj.shape_key_add(name=f"{base}_R", from_mix=False)
                    _copy_shape_key_settings(left, right, left.relative_key if left.relative_key else basis)
                    created += 1
                else:
                    repaired += 1
                got, count = _mirror_shape_key_geometry(obj, left, right, basis)
                matched += got
                total += count

        refresh_pair_sliders(obj)
        message = f"Mirror L/R: created {created}, repaired {repaired}"
        if renamed:
            message += f", renamed {renamed}"
        if skipped:
            message += f", skipped {skipped} duplicate name(s)"
        if total and matched < total:
            message += f", matched {matched}/{total} mirrored vertices"
        self.report({"INFO"}, message + ". Run Connect Shape Keys.")
        return {"FINISHED"}


# ─────────────────────────────
# CONNECT
# ─────────────────────────────
def _cleanup_stale_key_drivers(shape_keys):
    """Drop drivers that point to shape keys which no longer exist."""
    ad = shape_keys.animation_data
    if not ad:
        return 0
    names = {k.name for k in shape_keys.key_blocks}
    removed = 0
    for fc in list(ad.drivers):
        m = _KEY_DRIVER_RE.match(fc.data_path)
        if m and m.group(1) not in names:
            try:
                ad.drivers.remove(fc)
                removed += 1
            except Exception:
                pass
    return removed


def _add_scene_var(drv, name, scene, data_path):
    v = drv.variables.new()
    v.name = name
    v.type = "SINGLE_PROP"
    t = v.targets[0]
    # DriverTarget.id is typed by id_type (default OBJECT) -> must be set BEFORE assigning a Scene.
    t.id_type = "SCENE"
    t.id = scene
    t.data_path = data_path
    return v


# Each side is an independent animator control. Changing a display/balance
# setting must never alter a pose; paired controls expose explicit L and R
# values in the panel.
_EXPR_CENTER = "var * inten"


# ─────────────────────────────
# SOURCEIO HWM FLEX ADAPTER
# ─────────────────────────────
# SourceIO creates a mesh.flex_controllers collection and makes its shape-key
# drivers follow Source's original flex rules.  Replacing those shape-key
# drivers would break combination/corrective flexes, so Face Poser wraps the
# controller values instead.  The SourceIO rules remain entirely intact.
_HWM_PROP_PREFIX = "FP_HWM_"


def _sourceio_slot(controller):
    try:
        return controller.get_slot_name()
    except Exception:
        # Kept for forward compatibility with a SourceIO controller that does
        # not expose get_slot_name().  These match its four documented modes.
        return {1: "valuezo", 2: "valuenoo", 3: "valuenoz"}.get(
            int(getattr(controller, "mode", 0)), "valuen")


def _hwm_control_value(controller, slot):
    try:
        return float(getattr(controller, slot))
    except Exception:
        return 0.0


def _set_hwm_prop_range(obj, prop, controller):
    try:
        obj.id_properties_ui(prop).update(
            min=float(controller.value_min), max=float(controller.value_max),
            soft_min=float(controller.value_min), soft_max=float(controller.value_max),
        )
    except Exception:
        pass


def _add_object_prop_var(driver, name, obj, prop):
    variable = driver.variables.new()
    variable.name = name
    variable.type = "SINGLE_PROP"
    target = variable.targets[0]
    target.id_type = "OBJECT"
    target.id = obj
    target.data_path = _faceposer_prop_path(prop)
    return variable


def _add_hwm_controller_driver(obj, scene, controller, slot, source_prop, side=None):
    """Drive one SourceIO controller slot from a non-destructive FP_HWM_ value."""
    try:
        controller.driver_remove(slot)
    except Exception:
        pass

    fcurve = controller.driver_add(slot)
    for modifier in list(fcurve.modifiers):
        try:
            fcurve.modifiers.remove(modifier)
        except Exception:
            pass
    driver = fcurve.driver
    driver.type = "SCRIPTED"
    _add_object_prop_var(driver, "var", obj, source_prop)
    _add_scene_var(driver, "inten", scene, "faceposer_ui.intensity")

    # Stereo SourceIO slots already encode their side. Do not multiply them
    # by a global balance slider: the L and R Face Poser controls are direct,
    # independent inputs and changing UI state cannot reshape an existing pose.
    driver.expression = _EXPR_CENTER


def cleanup_hwm_properties(obj):
    """Remove FP_HWM_ values left behind by a changed SourceIO controller list."""
    if not obj or not hasattr(obj, "faceposer_hwm_controls"):
        return 0
    expected = set()
    for item in obj.faceposer_hwm_controls:
        if item.prop_left:
            expected.add(item.prop_left)
        if item.prop_right:
            expected.add(item.prop_right)
    removed = 0
    for prop in list(obj.keys()):
        if isinstance(prop, str) and prop.startswith(_HWM_PROP_PREFIX) and prop not in expected:
            try:
                del obj[prop]
                removed += 1
            except Exception:
                pass
    return removed


def setup_hwm_faceposer(obj, scene):
    """
    Build Face Poser proxies for all SourceIO flex controllers on *obj*.

    The generated FP_HWM_ object properties are the animator-facing values.
    Drivers apply intensity to native SourceIO slots independently per side;
    SourceIO then continues evaluating the compiled MDL's original HWM flex
    rules and corrective shape keys.  Calling this again is safe and keeps an
    existing per-side values rather than changing a pose when the side selector moves.
    """
    controllers = _sourceio_flex_controllers(obj)
    if not controllers or not hasattr(obj, "faceposer_hwm_controls"):
        return 0

    try:
        controls = list(controllers)
    except Exception:
        return 0
    if not controls:
        return 0

    items = obj.faceposer_hwm_controls
    items.clear()
    for index, controller in enumerate(controls):
        slot = _sourceio_slot(controller)
        is_stereo = bool(getattr(controller, "stereo", False))
        item = items.add()
        item.name = f"HWM_{index:03d}"
        item.label = getattr(controller, "name", f"Flex {index + 1}") or f"Flex {index + 1}"
        item.stereo = is_stereo
        minimum = float(getattr(controller, "value_min", 0.0))
        maximum = float(getattr(controller, "value_max", 1.0))
        scale = max(abs(minimum), abs(maximum), 1e-8)

        if is_stereo:
            for side, field in (("L", f"{slot}_left"), ("R", f"{slot}_right")):
                prop = f"{_HWM_PROP_PREFIX}{index:03d}_{side}"
                if prop not in obj:
                    obj[prop] = _hwm_control_value(controller, field)
                _set_hwm_prop_range(obj, prop, controller)
                _add_hwm_controller_driver(obj, scene, controller, field, prop, side)
                if side == "L":
                    item.prop_left = prop
                    item.left_min, item.left_max, item.left_scale = minimum, maximum, scale
                else:
                    item.prop_right = prop
                    item.right_min, item.right_max, item.right_scale = minimum, maximum, scale
        else:
            prop = f"{_HWM_PROP_PREFIX}{index:03d}_M"
            if prop not in obj:
                obj[prop] = _hwm_control_value(controller, slot)
            _set_hwm_prop_range(obj, prop, controller)
            _add_hwm_controller_driver(obj, scene, controller, slot, prop)
            item.prop_left = prop
            item.left_min, item.left_max, item.left_scale = minimum, maximum, scale

        normalized = []
        if item.prop_left in obj:
            normalized.append(float(obj[item.prop_left]) / max(item.left_scale, 1e-8))
        if item.stereo and item.prop_right in obj:
            normalized.append(float(obj[item.prop_right]) / max(item.right_scale, 1e-8))
        item.syncing = True
        item.value = max(-1.0, min(1.0, sum(normalized) / len(normalized))) if normalized else 0.0
        item.syncing = False

    cleanup_hwm_properties(obj)
    return 1


class FACEPOSER_OT_prepare_hwm(bpy.types.Operator):
    bl_idname = "faceposer.prepare_hwm"
    bl_label = "Prepare Source HWM Flexes"
    bl_description = "Keep SourceIO's HWM flex rules and connect them to Face Poser"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = get_mesh(context)
        if not obj or not _has_sourceio_flexes(obj):
            self.report({"WARNING"}, "Select a SourceIO mesh imported with 'Create drivers for flexes'")
            return {"CANCELLED"}
        setup_hwm_faceposer(obj, context.scene)
        self.report({"INFO"}, f"Prepared {len(obj.faceposer_hwm_controls)} HWM flex controller(s)")
        return {"FINISHED"}


class FACEPOSER_OT_connect(bpy.types.Operator):
    bl_idname = "faceposer.connect"
    bl_label = "Connect Shape Keys"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ensure_object_mode(context)
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        # SourceIO HWM meshes already have shape-key drivers that implement
        # the MDL flex rules.  Do not overwrite them with one driver per key.
        controllers = _sourceio_flex_controllers(obj)
        if controllers is not None and len(controllers) > 0:
            setup_hwm_faceposer(obj, context.scene)
            self.report({"INFO"}, f"HWM Face Poser connected: {len(obj.faceposer_hwm_controls)} controller(s)")
            return {"FINISHED"}

        renamed, skipped = smart_rename(obj)
        removed = cleanup_faceposer_properties(obj)
        cleanup_favorites(context.scene, obj)

        shape_keys = obj.data.shape_keys
        _cleanup_stale_key_drivers(shape_keys)

        scene = context.scene
        for key in shape_keys.key_blocks:
            if _is_basis_key(shape_keys, key):
                continue

            canonical = _canonical_name(key.name)
            prop = _shape_key_prop(obj, key)

            if prop not in obj:
                obj[prop] = key.value
                obj.id_properties_ui(prop).update(min=0, max=1)

            try:
                key.driver_remove("value")
            except Exception:
                pass

            drv = key.driver_add("value").driver
            drv.type = "SCRIPTED"

            var = drv.variables.new()
            var.name = "var"
            var.type = "SINGLE_PROP"
            var.targets[0].id_type = "OBJECT"
            var.targets[0].id = obj
            var.targets[0].data_path = _faceposer_prop_path(prop)

            _add_scene_var(drv, "inten", scene, "faceposer_ui.intensity")

            # L/R keys are already side-specific. A global balance value must
            # not retroactively change their evaluated values.
            drv.expression = _EXPR_CENTER

        refresh_pair_sliders(obj)

        msgs = []
        if renamed:
            msgs.append(f"renamed {renamed}")
        if skipped:
            msgs.append(f"skipped {skipped} (name already taken)")
        if removed:
            msgs.append(f"removed {removed} duplicate/stale sliders")
        if msgs:
            self.report({"INFO"}, "Connect: " + ", ".join(msgs))
        return {"FINISHED"}


# ─────────────────────────────
# KEYFRAMES
# ─────────────────────────────
class FACEPOSER_OT_insert_keyframes(bpy.types.Operator):
    bl_idname = "faceposer.insert_keyframes"
    bl_label = "Key All"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        for p in obj.keys():
            if _is_faceposer_prop(p):
                obj.keyframe_insert(data_path=f'["{p}"]')

        return {"FINISHED"}


class FACEPOSER_OT_remove_keyframes(bpy.types.Operator):
    bl_idname = "faceposer.remove_keyframes"
    bl_label = "Del Keys"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        for p in obj.keys():
            if _is_faceposer_prop(p):
                try:
                    obj.keyframe_delete(data_path=f'["{p}"]')
                except Exception:
                    pass

        return {"FINISHED"}


# ─────────────────────────────
# UTIL OPS
# ─────────────────────────────
def _favorite_index(scene, key: str):
    if not scene or not hasattr(scene, "faceposer_favorites"):
        return -1
    for i, item in enumerate(scene.faceposer_favorites):
        if item.key == key:
            return i
    return -1


def _toggle_favorite(scene, key: str):
    idx = _favorite_index(scene, key)
    if idx >= 0:
        scene.faceposer_favorites.remove(idx)
        return False
    item = scene.faceposer_favorites.add()
    item.key = key
    return True


class FACEPOSER_OT_apply_preset(bpy.types.Operator):
    bl_idname = "faceposer.apply_preset"
    bl_label = "Apply Preset"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        ui = getattr(context.scene, "faceposer_ui", None)
        _set_preset(ui)
        return {"FINISHED"}


class FACEPOSER_OT_set_filter(bpy.types.Operator):
    bl_idname = "faceposer.set_filter"
    bl_label = "Set Filter"

    text: StringProperty(name="Text", default="")
    group: StringProperty(name="Group", default="")

    def execute(self, context):
        ui = getattr(context.scene, "faceposer_ui", None)
        if not ui:
            return {"CANCELLED"}
        ui.search = self.text
        if self.group:
            ui.solo_group = self.group
        return {"FINISHED"}


class FACEPOSER_OT_toggle_favorite(bpy.types.Operator):
    bl_idname = "faceposer.toggle_favorite"
    bl_label = "Toggle Favorite"

    key: StringProperty(name="Key", default="")

    def execute(self, context):
        if not self.key:
            return {"CANCELLED"}
        _toggle_favorite(context.scene, self.key)
        return {"FINISHED"}


class FACEPOSER_OT_clear_favorites(bpy.types.Operator):
    bl_idname = "faceposer.clear_favorites"
    bl_label = "Clear Favorites"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        favs = getattr(context.scene, "faceposer_favorites", None)
        if favs is None:
            return {"CANCELLED"}
        favs.clear()
        return {"FINISHED"}


class FACEPOSER_OT_cleanup(bpy.types.Operator):
    bl_idname = "faceposer.cleanup"
    bl_label = "Cleanup"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        removed_props = cleanup_faceposer_properties(obj)
        removed_hwm = cleanup_hwm_properties(obj)
        refresh_pair_sliders(obj)
        removed_favs = cleanup_favorites(context.scene, obj)

        msg = []
        if removed_props:
            msg.append(f"removed {removed_props} SK_ props")
        if removed_hwm:
            msg.append(f"removed {removed_hwm} stale HWM props")
        if removed_favs:
            msg.append(f"removed {removed_favs} favorites")
        self.report({"INFO"}, "Cleanup: " + (", ".join(msg) if msg else "nothing to do"))
        return {"FINISHED"}


class FACEPOSER_OT_zero_side(bpy.types.Operator):
    bl_idname = "faceposer.zero_side"
    bl_label = "Zero Side"
    bl_options = {"REGISTER", "UNDO"}

    side: EnumProperty(items=[("L", "Left", ""), ("R", "Right", "")], name="Side")

    def execute(self, context):
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        suffix = "_L" if self.side == "L" else "_R"
        for p in list(obj.keys()):
            if _is_shape_key_prop(p) and _canonical_name(_control_label(obj, p)).endswith(suffix):
                obj[p] = 0.0
        for item in getattr(obj, "faceposer_hwm_controls", []):
            prop = item.prop_left if self.side == "L" else item.prop_right
            if prop and prop in obj:
                obj[prop] = 0.0
        return {"FINISHED"}


class FACEPOSER_OT_mirror_side(bpy.types.Operator):
    bl_idname = "faceposer.mirror_side"
    bl_label = "Mirror Side"
    bl_options = {"REGISTER", "UNDO"}

    source: EnumProperty(items=[("L", "L → R", ""), ("R", "R → L", "")], name="Source")

    def execute(self, context):
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        if not hasattr(obj, "faceposer_pair_sliders"):
            return {"CANCELLED"}

        for item in obj.faceposer_pair_sliders:
            base = item.name
            pL = _shape_key_prop(obj, f"{base}_L")
            pR = _shape_key_prop(obj, f"{base}_R")
            if pL not in obj or pR not in obj:
                continue
            if self.source == "L":
                obj[pR] = float(obj[pL])
            else:
                obj[pL] = float(obj[pR])
        for item in getattr(obj, "faceposer_hwm_controls", []):
            if not item.stereo or not item.prop_left or not item.prop_right:
                continue
            if item.prop_left not in obj or item.prop_right not in obj:
                continue
            if self.source == "L":
                obj[item.prop_right] = float(obj[item.prop_left])
            else:
                obj[item.prop_left] = float(obj[item.prop_right])
        return {"FINISHED"}


def _visible_props(context, obj, pairs_only=False):
    ui = getattr(context.scene, "faceposer_ui", None)
    if not ui or not obj:
        return []

    search = (ui.search or "").strip().lower()
    only_active = bool(ui.only_active)
    simple_mode = bool(ui.simple_mode)
    show_pairs = bool(ui.show_trifecta)
    show_singles = bool(ui.show_singles)
    show_center = bool(ui.show_center)
    show_other = bool(ui.show_other)
    hide_center_if_paired = bool(ui.hide_center_if_paired)
    solo = ui.solo_group if ui.solo_group else "ALL"

    controllers = _sourceio_flex_controllers(obj)
    if controllers is not None and len(controllers) > 0:
        props = []
        for item in getattr(obj, "faceposer_hwm_controls", []):
            label = item.label or item.name
            if search and search not in label.lower():
                continue
            if solo != "ALL" and get_group(label) != solo:
                continue
            if pairs_only and not item.stereo:
                continue
            candidates = [item.prop_left]
            if item.stereo:
                candidates.append(item.prop_right)
            values = [abs(float(obj.get(prop, 0.0))) for prop in candidates if prop]
            if only_active and not any(value > 1e-6 for value in values):
                continue
            props.extend(prop for prop in candidates if prop in obj)
        return props

    paired_bases = set()
    if hasattr(obj, "faceposer_pair_sliders"):
        paired_bases = {it.name for it in obj.faceposer_pair_sliders}

    def name_ok(n: str) -> bool:
        return (not search) or (search in n.lower())

    def prop_active(prop: str) -> bool:
        try:
            return abs(float(obj.get(prop, 0.0))) > 1e-6
        except Exception:
            return False

    props = []

    if (not simple_mode) and show_pairs and hasattr(obj, "faceposer_pair_sliders") and (pairs_only or show_pairs):
        for base in paired_bases:
            if solo != "ALL" and get_group(base) != solo:
                continue
            if not name_ok(base):
                continue
            pL = _shape_key_prop(obj, f"{base}_L")
            pR = _shape_key_prop(obj, f"{base}_R")
            if pL in obj:
                if (not only_active) or prop_active(pL) or prop_active(pR):
                    props.append(pL)
            if pR in obj:
                if (not only_active) or prop_active(pL) or prop_active(pR):
                    props.append(pR)

    if pairs_only:
        return props

    if show_singles or not simple_mode:
        for p in obj.keys():
            if not _is_shape_key_prop(p):
                continue
            name = _canonical_name(_control_label(obj, p))
            if solo != "ALL" and get_group(name) != solo:
                continue
            if not name_ok(name):
                continue
            if only_active and not prop_active(p):
                continue

            base = _base_from_lr(name)
            if (not simple_mode) and base and base in paired_bases:
                continue

            side = get_side(name)
            if not show_singles and side == "C":
                continue
            if side == "C" and not show_center:
                continue
            if (not simple_mode) and side == "C" and hide_center_if_paired and name in paired_bases:
                continue

            if get_group(name) == "Other" and not show_other:
                continue

            props.append(p)

    return props


class FACEPOSER_OT_insert_keyframes_active(bpy.types.Operator):
    bl_idname = "faceposer.insert_keyframes_active"
    bl_label = "Key Active"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        keyed = 0
        for p in obj.keys():
            if _is_faceposer_prop(p):
                try:
                    if abs(float(obj.get(p, 0.0))) > 1e-6:
                        obj.keyframe_insert(data_path=f'["{p}"]')
                        keyed += 1
                except Exception:
                    pass
        self.report({"INFO"}, f"Keyed {keyed} active controls")
        return {"FINISHED"}


class FACEPOSER_OT_insert_keyframes_visible(bpy.types.Operator):
    bl_idname = "faceposer.insert_keyframes_visible"
    bl_label = "Key Visible"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        props = _visible_props(context, obj, pairs_only=False)
        for p in props:
            obj.keyframe_insert(data_path=f'["{p}"]')
        self.report({"INFO"}, f"Keyed {len(props)} visible controls")
        return {"FINISHED"}


class FACEPOSER_OT_insert_keyframes_pairs(bpy.types.Operator):
    bl_idname = "faceposer.insert_keyframes_pairs"
    bl_label = "Key Pairs"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        props = _visible_props(context, obj, pairs_only=True)
        for p in props:
            obj.keyframe_insert(data_path=f'["{p}"]')
        self.report({"INFO"}, f"Keyed {len(props)} pair controls")
        return {"FINISHED"}


class FACEPOSER_OT_export_pose(bpy.types.Operator, ExportHelper):
    bl_idname = "faceposer.export_pose"
    bl_label = "Export Pose"
    filename_ext = ".json"

    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def execute(self, context):
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        ui = getattr(context.scene, "faceposer_ui", None)
        data = {
            "addon": "sfm_importer_faceposer",
            "format": 2,
            "intensity": float(ui.intensity) if ui else 1.0,
            "props": {},
        }
        for p in obj.keys():
            if _is_faceposer_prop(p):
                try:
                    data["props"][p] = float(obj.get(p, 0.0))
                except Exception:
                    pass

        # Index-based FP_HWM_ properties are perfect for the same mesh, but
        # controller order can differ between otherwise compatible Source
        # models.  Store an additional semantic HWM map for portable poses.
        if _has_sourceio_flexes(obj):
            data["hwm_controls"] = []
            for item in getattr(obj, "faceposer_hwm_controls", []):
                entry = {"name": item.label, "stereo": bool(item.stereo)}
                if item.prop_left in obj:
                    entry["left"] = float(obj[item.prop_left])
                if item.stereo and item.prop_right in obj:
                    entry["right"] = float(obj[item.prop_right])
                data["hwm_controls"].append(entry)

        with open(self.filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        self.report({"INFO"}, f"Exported pose: {len(data['props'])} controls")
        return {"FINISHED"}


class FACEPOSER_OT_import_pose(bpy.types.Operator, ImportHelper):
    bl_idname = "faceposer.import_pose"
    bl_label = "Import Pose"
    filename_ext = ".json"

    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})
    only_existing: BoolProperty(name="Only Existing", default=True)

    def execute(self, context):
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        with open(self.filepath, "r", encoding="utf-8") as f:
            data = json.load(f)

        props = data.get("props", {})
        hwm_pose = data.get("hwm_controls", [])
        if _has_sourceio_flexes(obj) and not getattr(obj, "faceposer_hwm_controls", None):
            setup_hwm_faceposer(obj, context.scene)
        applied = 0
        for p, v in props.items():
            if not _is_faceposer_prop(p):
                continue
            # When semantic HWM data is available, do not first apply stale
            # controller-index properties from a different compatible model.
            if hwm_pose and isinstance(p, str) and p.startswith(_HWM_PROP_PREFIX):
                continue
            if self.only_existing and p not in obj:
                continue
            try:
                obj[p] = float(v)
                applied += 1
            except Exception:
                pass

        if hwm_pose and _has_sourceio_flexes(obj):
            controls = {
                (item.label or item.name).casefold(): item
                for item in getattr(obj, "faceposer_hwm_controls", [])
            }
            for entry in hwm_pose:
                if not isinstance(entry, dict):
                    continue
                item = controls.get(str(entry.get("name", "")).casefold())
                if not item:
                    continue
                for field, prop in (("left", item.prop_left), ("right", item.prop_right)):
                    if prop not in obj or field not in entry:
                        continue
                    try:
                        obj[prop] = float(entry[field])
                        applied += 1
                    except Exception:
                        pass

        refresh_pair_sliders(obj)
        self.report({"INFO"}, f"Imported pose: {applied} controls")
        return {"FINISHED"}

# ─────────────────────────────
# RESET
# ─────────────────────────────
class FACEPOSER_OT_reset_all(bpy.types.Operator):
    bl_idname = "faceposer.reset_all"
    bl_label = "Reset All"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = get_mesh(context)
        if not obj:
            return {"CANCELLED"}

        for p in obj.keys():
            if _is_faceposer_prop(p):
                obj[p] = 0.0

        ui = getattr(context.scene, "faceposer_ui", None)
        if ui:
            ui.balance = 0.0

        for item in getattr(obj, "faceposer_hwm_controls", []):
            item.syncing = True
            item.value = 0.0
            item.syncing = False

        refresh_pair_sliders(obj)
        return {"FINISHED"}


def _balance_side_weights(context):
    """Smooth L/R weights used only when a main controller is edited."""
    ui = getattr(getattr(context, "scene", None), "faceposer_ui", None)
    balance = float(ui.balance) if ui else 0.0
    if ui and ui.balance_flip:
        balance = -balance
    balance = max(-1.0, min(1.0, balance))
    left = 1.0 - _smoothstep01(max(0.0, balance))
    right = 1.0 - _smoothstep01(max(0.0, -balance))
    return left, right


def _pair_value_update(self, context):
    obj = self.id_data
    if not obj or self.syncing:
        return
    base = self.name
    val = float(self.value)
    left_weight, right_weight = _balance_side_weights(context)

    auto_key = False
    try:
        ts = context.scene.tool_settings if context and context.scene else None
        auto_key = bool(ts.use_keyframe_insert_auto) if ts else False
    except Exception:
        auto_key = False

    for suffix, weight in (("_L", left_weight), ("_R", right_weight)):
        # At a hard L/R endpoint, leave the opposite side untouched instead
        # of writing zero over its previously posed value.
        if weight <= 1e-6:
            continue
        prop = _shape_key_prop(obj, f"{base}{suffix}")
        if prop in obj:
            obj[prop] = val * weight
            if auto_key:
                try:
                    obj.keyframe_insert(data_path=f'["{prop}"]')
                except Exception:
                    pass


def _hwm_main_value_update(self, context):
    obj = self.id_data
    if not obj or self.syncing:
        return
    left_weight, right_weight = _balance_side_weights(context) if self.stereo else (1.0, 0.0)
    val = float(self.value)
    auto_key = False
    try:
        auto_key = bool(context.scene.tool_settings.use_keyframe_insert_auto)
    except Exception:
        pass

    for prop, weight, scale, min_value, max_value in (
        (self.prop_left, left_weight, self.left_scale, self.left_min, self.left_max),
        (self.prop_right, right_weight, self.right_scale, self.right_min, self.right_max),
    ):
        if weight <= 1e-6:
            continue
        if not prop or prop not in obj:
            continue
        value = max(min_value, min(max_value, val * scale * weight))
        obj[prop] = value
        if auto_key:
            try:
                obj.keyframe_insert(data_path=f'["{prop}"]')
            except Exception:
                pass


class FACEPOSER_PairItem(bpy.types.PropertyGroup):
    name: StringProperty(name="Name", default="")
    syncing: BoolProperty(default=False, options={"HIDDEN"})
    value: FloatProperty(name="Control", default=0.0, min=0.0, max=1.0, update=_pair_value_update)


class FACEPOSER_HWMControlItem(bpy.types.PropertyGroup):
    """One animator-facing proxy for a SourceIO HWM flex controller."""
    name: StringProperty(name="Identifier", default="")
    label: StringProperty(name="Label", default="")
    stereo: BoolProperty(name="Stereo", default=False)
    prop_left: StringProperty(name="Left/Mono Property", default="")
    prop_right: StringProperty(name="Right Property", default="")
    syncing: BoolProperty(default=False, options={"HIDDEN"})
    value: FloatProperty(name="Control", default=0.0, min=-1.0, max=1.0, update=_hwm_main_value_update)
    left_min: FloatProperty(default=0.0, options={"HIDDEN"})
    left_max: FloatProperty(default=1.0, options={"HIDDEN"})
    right_min: FloatProperty(default=0.0, options={"HIDDEN"})
    right_max: FloatProperty(default=1.0, options={"HIDDEN"})
    left_scale: FloatProperty(default=1.0, min=0.0, options={"HIDDEN"})
    right_scale: FloatProperty(default=1.0, min=0.0, options={"HIDDEN"})


class FACEPOSER_FavoriteItem(bpy.types.PropertyGroup):
    # key is "PAIR:<base>" or "PROP:<SK_prop_name>"
    key: StringProperty(name="Key", default="")


class FACEPOSER_UISettings(bpy.types.PropertyGroup):
    preset: EnumProperty(
        name="Preset",
        items=[
            ("CLEAN", "Clean", "Pairs only, minimal clutter"),
            ("ANIM", "Animator", "Pairs + Singles, active-friendly"),
            ("DEBUG", "Debug", "Show everything"),
        ],
        default="CLEAN",
    )
    search: StringProperty(name="Filter", default="", description="Filter controls by name")
    only_active: BoolProperty(name="Only Active", default=False, description="Show only non-zero controls")
    simple_mode: BoolProperty(
        name="Simple",
        default=False,
        description="Hide Pairs rows and show plain L/R sliders instead",
    )
    intensity: FloatProperty(
        name="Intensity",
        default=1.0,
        min=0.0,
        max=2.0,
        description="Global multiplier for all connected shape keys (driver)",
    )
    balance: FloatProperty(
        name="Balance",
        default=0.0,
        min=-1.0,
        max=1.0,
        description="Choose which side the NEXT main controller edit affects. Moving this slider alone never changes the current face pose; center affects both sides with a smooth falloff",
    )
    balance_flip: BoolProperty(
        name="Flip Balance",
        default=False,
        description="Swap which side the left end of the Balance slider controls",
    )
    split_falloff: FloatProperty(
        name="Split Falloff",
        default=0.12,
        min=0.001,
        max=0.5,
        subtype='FACTOR',
        description="Width of the smooth central blend used when splitting a centre shape key",
    )
    show_individual_sides: BoolProperty(
        name="Individual L/R controls",
        default=False,
        description="Show direct left/right override sliders below each main controller",
    )
    solo_group: EnumProperty(
        name="Solo Group",
        items=SOLO_GROUP_ITEMS,
        description="Show only one group",
        default="ALL",
    )
    common_first: BoolProperty(
        name="Common First",
        default=True,
        description="Sort common controls first",
    )
    show_trifecta: BoolProperty(
        name="Pairs",
        default=True,
        description="Show paired controls (Both / L / R)",
    )
    show_singles: BoolProperty(
        name="Singles",
        default=True,
        description="Show non-paired controls (Center + any unpaired L/R)",
    )
    show_center: BoolProperty(name="Show Center", default=False, description="Show center (unsided) controls")
    show_other: BoolProperty(
        name="Show Other",
        default=False,
        description="Show unpaired controls in 'Other' (L/R pairs are always shown together)",
    )
    hide_center_if_paired: BoolProperty(
        name="Hide Center If Paired",
        default=True,
        description="Hide center control when an L/R pair exists for the same base",
    )


def _set_preset(ui: "FACEPOSER_UISettings"):
    if not ui:
        return

    ui.solo_group = "ALL"
    ui.search = ""

    if ui.preset == "CLEAN":
        ui.only_active = False
        ui.simple_mode = False
        ui.show_trifecta = True
        ui.show_singles = True
        ui.show_center = False
        ui.show_other = True
        ui.common_first = True
    elif ui.preset == "ANIM":
        ui.only_active = False
        ui.simple_mode = False
        ui.show_trifecta = True
        ui.show_singles = True
        ui.show_center = False
        ui.show_other = False
        ui.common_first = True
    elif ui.preset == "DEBUG":
        ui.only_active = False
        ui.simple_mode = True
        ui.show_trifecta = True
        ui.show_singles = True
        ui.show_center = True
        ui.show_other = True
        ui.common_first = False


# ─────────────────────────────
# UI
# ─────────────────────────────
def _draw_hwm_controls(layout, context, obj, ui):
    """Draw SourceIO controllers without exposing or damaging flex-rule keys."""
    controls = getattr(obj, "faceposer_hwm_controls", None)
    if not controls or len(controls) == 0:
        box = layout.box()
        box.label(text="SourceIO HWM flexes found", icon="SHAPEKEY_DATA")
        box.label(text="Press Prepare HWM Flexes to create animator controls.")
        return

    search = (ui.search or "").strip().lower() if ui else ""
    only_active = bool(ui.only_active) if ui else False
    solo_group = ui.solo_group if (ui and ui.solo_group) else "ALL"
    common_first = bool(ui.common_first) if ui else True

    def name_ok(name):
        return not search or search in name.lower()

    def active(item):
        try:
            left = abs(float(obj.get(item.prop_left, 0.0))) if item.prop_left else 0.0
            right = abs(float(obj.get(item.prop_right, 0.0))) if item.prop_right else 0.0
            return max(left, right) > 1e-6
        except Exception:
            return False

    grouped = {group: [] for group in list(GROUPS) + ["Other"]}
    for item in controls:
        label = item.label or item.name
        if not name_ok(label) or (only_active and not active(item)):
            continue
        group = get_group(label)
        if solo_group != "ALL" and group != solo_group:
            continue
        grouped.setdefault(group, []).append(item)

    common_order = [name.lower() for name in NAME_MAP.values()]

    def sort_items(items):
        if not common_first:
            return sorted(items, key=lambda item: (item.label or item.name).lower())
        def key(item):
            label = (item.label or item.name).lower()
            rank = next((i for i, name in enumerate(common_order) if name in label), 999)
            return rank, label
        return sorted(items, key=key)

    for group, items in grouped.items():
        if not items:
            continue
        box = layout.box()
        box.label(text=group, icon="SHAPEKEY_DATA")
        col = box.column(align=True)
        for item in sort_items(items):
            row = col.row(align=True)
            row.label(text=item.label or item.name)
            if item.stereo:
                if item.prop_left in obj:
                    row.prop(obj, _faceposer_prop_path(item.prop_left), slider=True, text="L")
                if item.prop_right in obj:
                    row.prop(obj, _faceposer_prop_path(item.prop_right), slider=True, text="R")
            elif item.prop_left in obj:
                row.prop(obj, _faceposer_prop_path(item.prop_left), slider=True, text="")


def _shape_key_label_map(obj):
    """Build prop->name lookup once; avoid a full key scan for every row."""
    result = {}
    shape_keys = getattr(getattr(obj, "data", None), "shape_keys", None)
    if not shape_keys:
        return result
    for key in shape_keys.key_blocks:
        if not _is_basis_key(shape_keys, key):
            result[_shape_key_prop(obj, key.name)] = _canonical_name(key.name)
    return result


def _draw_faceposer_group(layout, context, obj, group_name):
    """Draw only one compact category inside its own collapsible panel."""
    ui = getattr(context.scene, "faceposer_ui", None)
    if not ui:
        return
    search = (ui.search or "").strip().lower()
    only_active = bool(ui.only_active)
    simple_mode = bool(ui.simple_mode)

    def matches(label):
        return (not search or search in label.lower()) and get_group(label) == group_name

    def active(prop):
        try:
            return abs(float(obj.get(prop, 0.0))) > 1e-6
        except Exception:
            return False

    controllers = _sourceio_flex_controllers(obj)
    if controllers is not None and len(controllers) > 0:
        items = [it for it in getattr(obj, "faceposer_hwm_controls", [])
                 if matches(it.label or it.name)]
        for item in items:
            left = item.prop_left
            right = item.prop_right
            if only_active and not (active(left) or active(right)):
                continue
            row = layout.row(align=True)
            row.label(text=(item.label or item.name)[:28])
            row.prop(item, "value", slider=True, text="Control")
            if ui.show_individual_sides:
                sides = layout.row(align=True)
                if left in obj:
                    sides.prop(obj, _faceposer_prop_path(left), slider=True, text="L")
                if item.stereo and right in obj:
                    sides.prop(obj, _faceposer_prop_path(right), slider=True, text="R")
        return

    pair_items = {it.name: it for it in getattr(obj, "faceposer_pair_sliders", [])}
    paired_bases = set(pair_items)
    favorite_keys = {fav.key for fav in getattr(context.scene, "faceposer_favorites", [])}
    if not simple_mode and ui.show_trifecta:
        for base in sorted(paired_bases, key=str.lower):
            if not matches(base):
                continue
            p_left = _shape_key_prop(obj, f"{base}_L")
            p_right = _shape_key_prop(obj, f"{base}_R")
            if p_left not in obj or p_right not in obj:
                continue
            if only_active and not (active(p_left) or active(p_right)):
                continue
            row = layout.row(align=True)
            op = row.operator("faceposer.toggle_favorite", text="",
                              icon="SOLO_ON" if f"PAIR:{base}" in favorite_keys else "SOLO_OFF")
            op.key = f"PAIR:{base}"
            row.label(text=base[:27])
            row.prop(pair_items[base], "value", slider=True, text="Control")
            if ui.show_individual_sides:
                sides = layout.row(align=True)
                sides.prop(obj, _faceposer_prop_path(p_left), slider=True, text="L")
                sides.prop(obj, _faceposer_prop_path(p_right), slider=True, text="R")

    labels = _shape_key_label_map(obj)
    single_rows = []
    for prop in obj.keys():
        if not _is_shape_key_prop(prop):
            continue
        name = labels.get(prop)
        if name is None:
            name = _canonical_name(_control_label(obj, prop))
        if not matches(name) or (only_active and not active(prop)):
            continue
        base = _base_from_lr(name)
        if not simple_mode and base in paired_bases and ui.show_trifecta:
            continue
        side = get_side(name)
        if not ui.show_singles and not simple_mode:
            continue
        if side == "C" and (not ui.show_center or
                            (ui.hide_center_if_paired and name in paired_bases)):
            continue
        single_rows.append((name.lower(), prop, name))

    for _, prop, name in sorted(single_rows):
        row = layout.row(align=True)
        fav_key = f"PROP:{prop}"
        is_fav = fav_key in favorite_keys
        op = row.operator("faceposer.toggle_favorite", text="", icon="SOLO_ON" if is_fav else "SOLO_OFF")
        op.key = fav_key
        row.prop(obj, _faceposer_prop_path(prop), slider=True, text=name[:27])


class _FACEPOSER_GROUP_PANEL_BASE:
    """Shared panel behavior for the collapsible control categories."""
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_parent_id = "FACEPOSER_PT_panel"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        if get_mesh(context) is None:
            return False
        ui = getattr(context.scene, "faceposer_ui", None)
        return not ui or ui.solo_group in {"ALL", cls.group_name}

    def draw(self, context):
        obj = get_mesh(context)
        if obj:
            _draw_faceposer_group(self.layout, context, obj, self.group_name)


class FACEPOSER_PT_group_eyes(_FACEPOSER_GROUP_PANEL_BASE, bpy.types.Panel):
    bl_label = "Eyes"
    bl_idname = "FACEPOSER_PT_group_eyes"
    group_name = "Eyes"


class FACEPOSER_PT_group_brows(_FACEPOSER_GROUP_PANEL_BASE, bpy.types.Panel):
    bl_label = "Brows"
    bl_idname = "FACEPOSER_PT_group_brows"
    group_name = "Brows"


class FACEPOSER_PT_group_cheeks(_FACEPOSER_GROUP_PANEL_BASE, bpy.types.Panel):
    bl_label = "Cheeks"
    bl_idname = "FACEPOSER_PT_group_cheeks"
    group_name = "Cheeks"


class FACEPOSER_PT_group_nose(_FACEPOSER_GROUP_PANEL_BASE, bpy.types.Panel):
    bl_label = "Nose"
    bl_idname = "FACEPOSER_PT_group_nose"
    group_name = "Nose"


class FACEPOSER_PT_group_mouth(_FACEPOSER_GROUP_PANEL_BASE, bpy.types.Panel):
    bl_label = "Mouth"
    bl_idname = "FACEPOSER_PT_group_mouth"
    group_name = "Mouth"


class FACEPOSER_PT_group_lips(_FACEPOSER_GROUP_PANEL_BASE, bpy.types.Panel):
    bl_label = "Lips"
    bl_idname = "FACEPOSER_PT_group_lips"
    group_name = "Lips"


class FACEPOSER_PT_group_tongue(_FACEPOSER_GROUP_PANEL_BASE, bpy.types.Panel):
    bl_label = "Tongue"
    bl_idname = "FACEPOSER_PT_group_tongue"
    group_name = "Tongue"


class FACEPOSER_PT_group_other(_FACEPOSER_GROUP_PANEL_BASE, bpy.types.Panel):
    bl_label = "Other"
    bl_idname = "FACEPOSER_PT_group_other"
    group_name = "Other"


class FACEPOSER_PT_panel(bpy.types.Panel):
    bl_label = "Face Poser"
    bl_idname = "FACEPOSER_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "SFM Import"

    def draw(self, context):
        layout = self.layout
        obj = get_mesh(context)
        ui = getattr(context.scene, "faceposer_ui", None)
        if not obj:
            layout.label(text="Select a mesh with shape keys or SourceIO HWM flexes.", icon="INFO")
            return
        is_hwm = _has_sourceio_flexes(obj) and len(_sourceio_flex_controllers(obj) or []) > 0
        row = layout.row(align=True)
        row.scale_y = 1.15
        if is_hwm:
            row.operator("faceposer.prepare_hwm", text="Prepare HWM", icon="DRIVER")
        else:
            row.operator("faceposer.connect", text="Connect Keys", icon="DRIVER")
        row.operator("faceposer.reset_all", text="Reset", icon="LOOP_BACK")

        row = layout.row(align=True)
        row.label(text="Stereo Balance")
        row.prop(ui, "balance", slider=True, text="L  ◄  Both  ►  R")

        row = layout.row(align=True)
        row.operator("faceposer.insert_keyframes", text="Key All", icon="KEY_HLT")
        row.prop(ui, "only_active", text="Active only", toggle=True)

        row = layout.row(align=True)
        row.prop(ui, "search", text="", icon="VIEWZOOM")
        row.prop(ui, "solo_group", text="")

        layout.label(text="Expand a face group below to edit its controls.", icon="INFO")


class FACEPOSER_PT_display(bpy.types.Panel):
    bl_label = "Display"
    bl_parent_id = "FACEPOSER_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        ui = getattr(context.scene, "faceposer_ui", None)
        layout = self.layout
        if not ui:
            layout.label(text="No UI settings")
            return

        col = layout.column(align=True)
        col.prop(ui, "intensity")
        col.prop(ui, "split_falloff")
        col.separator()
        col.prop(ui, "show_individual_sides", text="Individual L/R overrides")
        col.prop(ui, "show_trifecta", text="Paired L/R controls")
        col.prop(ui, "show_singles", text="Unpaired controls")
        col.prop(ui, "show_center", text="Center controls")
        col.prop(ui, "show_other", text="Other controls")
        col.prop(ui, "simple_mode", text="Simple list (no pair grouping)")


class FACEPOSER_PT_favorites(bpy.types.Panel):
    bl_label = "Favorites"
    bl_parent_id = "FACEPOSER_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        obj = get_mesh(context)
        if not obj:
            layout.label(text="Select a mesh with shape keys")
            return

        favs = getattr(context.scene, "faceposer_favorites", None)
        if not favs or len(favs) == 0:
            layout.label(text="No favorites yet")
            return

        row = layout.row(align=True)
        row.operator("faceposer.cleanup", text="Cleanup", icon="TRASH")
        row.operator("faceposer.clear_favorites", text="Clear", icon="X")

        paired_bases = set()
        pair_items = {}
        if hasattr(obj, "faceposer_pair_sliders"):
            paired_bases = {it.name for it in obj.faceposer_pair_sliders}
            pair_items = {it.name: it for it in obj.faceposer_pair_sliders}

        col = layout.column(align=True)
        for item in favs:
            key = item.key
            if key.startswith("PAIR:"):
                base = key[5:]
                if base not in paired_bases:
                    continue
                pL = _shape_key_prop(obj, f"{base}_L")
                pR = _shape_key_prop(obj, f"{base}_R")
                if pL not in obj or pR not in obj:
                    continue
                row = col.row(align=True)
                op = row.operator("faceposer.toggle_favorite", text="", icon="SOLO_ON")
                op.key = key
                label = base if len(base) <= 26 else base[:23] + "…"
                row.label(text=label)
                if base in pair_items:
                    row.prop(pair_items[base], "value", slider=True, text="Control")
                ui = getattr(context.scene, "faceposer_ui", None)
                if ui and ui.show_individual_sides:
                    sides = col.row(align=True)
                    sides.prop(obj, _faceposer_prop_path(pL), slider=True, text="L")
                    sides.prop(obj, _faceposer_prop_path(pR), slider=True, text="R")
            elif key.startswith("PROP:"):
                prop = key[5:]
                if prop not in obj:
                    continue
                row = col.row(align=True)
                op = row.operator("faceposer.toggle_favorite", text="", icon="SOLO_ON")
                op.key = key
                row.prop(obj, _faceposer_prop_path(prop), slider=True, text=_control_label(obj, prop))


class FACEPOSER_PT_tools(bpy.types.Panel):
    bl_label = "Tools"
    bl_parent_id = "FACEPOSER_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        obj = get_mesh(context)

        col = layout.column(align=True)
        col.operator("faceposer.rename_au", text="Smart Rename", icon="SORTALPHA")
        split = col.operator("faceposer.auto_split", text="Split Center Keys Smoothly", icon="IPO_EASE_IN_OUT")
        ui = getattr(context.scene, "faceposer_ui", None)
        if ui:
            split.falloff = ui.split_falloff
        col.operator("faceposer.cleanup", icon="TRASH")

        row = col.row(align=True)
        row.operator("faceposer.zero_side", text="Zero L").side = "L"
        row.operator("faceposer.zero_side", text="Zero R").side = "R"

        row = col.row(align=True)
        row.operator("faceposer.mirror_side", text="Mirror L→R").source = "L"
        row.operator("faceposer.mirror_side", text="Mirror R→L").source = "R"

        col.separator()
        col.label(text="Keying:")
        row = col.row(align=True)
        row.operator("faceposer.insert_keyframes_visible", text="Key Visible")
        row.operator("faceposer.insert_keyframes_active", text="Key Active")
        row = col.row(align=True)
        row.operator("faceposer.insert_keyframes_pairs", text="Key Pairs")
        row.operator("faceposer.remove_keyframes", text="Del Keys")

        col.separator()
        col.label(text="Pose I/O:")
        row = col.row(align=True)
        row.operator("faceposer.export_pose", text="Export")
        row.operator("faceposer.import_pose", text="Import")
        if obj:
            col.label(text=f"Object: {obj.name}")


# ============================================================================
# Registration
# ============================================================================

_sfm_classes = (
    SFMBoneKeep,
    SFMRigifySettings,
    SFMRIGIFY_OT_build_metarig,
    SFMRIGIFY_OT_generate_link,
    SFMRIGIFY_OT_convert,
    SFMRIGIFY_OT_relink,
    SFMRIGIFY_OT_unlink,
    SFMRIGIFY_OT_use_active,
    SFMRIGIFY_OT_eye_fix,
    SFMRIGIFY_OT_new_eye_shader,
    SFMRIGIFY_OT_eye_fix_remove,
    SFMRIGIFY_OT_bones_load,
    SFMRIGIFY_OT_bones_set,
    SFMRIGIFY_UL_bones,
    SFMIMPORT_Item,
    SFMIMPORT_Settings,
    SFMIMPORT_OT_scan,
    SFMIMPORT_OT_import,
    SFMIMPORT_UL_models,
    SFMIMPORT_PT_panel,     # importer panel first ...
    SFMOBJECTSWITCH_PT_panel,
    SFMRIGIFY_PT_panel,     # ... then "Rigify Existing Model" ...
)

_fp_classes = (
    FACEPOSER_PairItem,
    FACEPOSER_HWMControlItem,
    FACEPOSER_FavoriteItem,
    FACEPOSER_UISettings,
    FACEPOSER_OT_apply_preset,
    FACEPOSER_OT_set_filter,
    FACEPOSER_OT_toggle_favorite,
    FACEPOSER_OT_clear_favorites,
    FACEPOSER_OT_cleanup,
    FACEPOSER_OT_zero_side,
    FACEPOSER_OT_mirror_side,
    FACEPOSER_OT_insert_keyframes_active,
    FACEPOSER_OT_insert_keyframes_visible,
    FACEPOSER_OT_insert_keyframes_pairs,
    FACEPOSER_OT_export_pose,
    FACEPOSER_OT_import_pose,
    FACEPOSER_OT_rename_au,
    FACEPOSER_OT_create_missing_mirror_sides,
    FACEPOSER_OT_auto_split,
    FACEPOSER_OT_prepare_hwm,
    FACEPOSER_OT_connect,
    FACEPOSER_OT_insert_keyframes,
    FACEPOSER_OT_remove_keyframes,
    FACEPOSER_OT_reset_all,
    FACEPOSER_PT_panel,
    FACEPOSER_PT_group_eyes,
    FACEPOSER_PT_group_brows,
    FACEPOSER_PT_group_cheeks,
    FACEPOSER_PT_group_nose,
    FACEPOSER_PT_group_mouth,
    FACEPOSER_PT_group_lips,
    FACEPOSER_PT_group_tongue,
    FACEPOSER_PT_group_other,
    FACEPOSER_PT_display,
    FACEPOSER_PT_favorites,
    FACEPOSER_PT_tools,
)                           # ... and Face Poser at the bottom

classes = _sfm_classes + _fp_classes


def register():
    global _pcoll, _pv
    object_switch.register()
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.sfm_rigify = PointerProperty(type=SFMRigifySettings)
    bpy.types.Scene.sfm_import = PointerProperty(type=SFMIMPORT_Settings)
    bpy.types.Scene.faceposer_ui = PointerProperty(type=FACEPOSER_UISettings)
    bpy.types.Scene.faceposer_favorites = CollectionProperty(type=FACEPOSER_FavoriteItem)
    bpy.types.Object.faceposer_pair_sliders = CollectionProperty(type=FACEPOSER_PairItem)
    bpy.types.Object.faceposer_hwm_controls = CollectionProperty(type=FACEPOSER_HWMControlItem)
    _pcoll = bpy.utils.previews.new()
    _pv = _pcoll.new("sfm_model_preview")
    _pv.image_size = (PREVIEW_SIZE, PREVIEW_SIZE)
    bg = np.empty((PREVIEW_SIZE * PREVIEW_SIZE, 4), np.float32)
    bg[:] = BG_COLOR
    _pv.image_pixels_float.foreach_set(bg.ravel())


def unregister():
    global _pcoll, _pv
    if _pcoll is not None:
        bpy.utils.previews.remove(_pcoll)
    _pcoll = _pv = None
    _cache.clear()
    for attr in ("faceposer_ui", "faceposer_favorites", "sfm_import", "sfm_rigify"):
        if hasattr(bpy.types.Scene, attr):
            delattr(bpy.types.Scene, attr)
    if hasattr(bpy.types.Object, "faceposer_pair_sliders"):
        del bpy.types.Object.faceposer_pair_sliders
    if hasattr(bpy.types.Object, "faceposer_hwm_controls"):
        del bpy.types.Object.faceposer_hwm_controls
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
    object_switch.unregister()


if __name__ == "__main__":
    register()
